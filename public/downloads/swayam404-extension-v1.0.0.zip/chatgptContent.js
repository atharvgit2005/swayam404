(function(){"use strict";(function(){var C;if(typeof window>"u")return;const m=window;if(m.__swayamWebAiBridgeInstalled)return;m.__swayamWebAiBridgeInstalled=!0,console.log("[swayam404] Web AI Assistant Auto-Pilot Bridge active.");let g="",f=!1,d=null,c=null,l=null;function u(t,a="#1a1a1a",n="#f5f0e8"){d&&(d.textContent=t,d.style.color=a,d.style.backgroundColor=n)}function y(){return document.querySelector("#prompt-textarea")||document.querySelector('div[contenteditable="true"].ProseMirror')||document.querySelector('fieldset div[contenteditable="true"]')||document.querySelector('div[contenteditable="true"]')||document.querySelector("textarea")}function A(){return document.querySelector('button[data-testid="send-button"]')||document.querySelector('button[data-testid="composer-send-button"]')||document.querySelector('button[aria-label*="Send"]')||document.querySelector('button[aria-label*="send"]')||document.querySelector('button[aria-label="Send Message"]')}async function h(t,a=!0){const n=y();if(!n)return!1;try{navigator.clipboard.writeText(t)}catch{}n.focus();let e=!1;try{document.execCommand("selectAll",!1,void 0),e=document.execCommand("insertText",!1,t)}catch{e=!1}e||(n.tagName.toLowerCase()==="textarea"?n.value=t:n.innerHTML=`<p>${t.replace(/\n/g,"<br>")}</p>`),n.dispatchEvent(new Event("input",{bubbles:!0}));try{n.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:t}))}catch{}return a&&(u("⚡ Submitting to AI...","#1a1a1a","#ffcc00"),setTimeout(()=>{const o=A();o&&!o.disabled?o.click():n.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0})),u("⏳ AI Generating Answers...","#2563eb","#dbeafe"),P()},500)),!0}function b(){const t=[];document.querySelectorAll('[data-message-author-role="assistant"], article[data-message-author-role="assistant"], [data-testid*="assistant"], .agent-turn, [class*="agent-turn"]').forEach(e=>{t.includes(e)||t.push(e)}),document.querySelectorAll('div.font-claude-message, [class*="font-claude-message"], [class*="standard-markdown"], div.claude-message').forEach(e=>{t.includes(e)||t.push(e)}),document.querySelectorAll('main article, [role="presentation"] article, article').forEach(e=>{const o=e.getAttribute("data-message-author-role"),s=e.getAttribute("data-testid")||"";o==="user"||s.includes("user")||t.includes(e)||t.push(e)}),t.length===0&&document.querySelectorAll('div.markdown.prose, div.markdown, .markdown, [class*="markdown"], .prose, [class*="prose"]').forEach(e=>{t.includes(e)||t.push(e)});const a=document.querySelectorAll('pre code, pre, div[class*="code-block"]');let n="";if(t.length>0){const e=t[t.length-1],o=e.querySelector("pre code, code, pre");if(o){const s=(o.innerText||o.textContent||"").trim();s&&(s.includes("{")||s.includes("["))&&(n=s)}n||(n=(e.innerText||e.textContent||"").trim())}if(!n&&a.length>0){const e=a[a.length-1];n=(e.innerText||e.textContent||"").trim()}if(!n){const e=document.querySelector("main");if(e){const o=(e.innerText||e.textContent||"").trim();o&&(o.includes("{")||o.includes("["))&&(n=o)}}return n=n.replace(/^(?:JSON\s*)?(?:Copy code\s*)?/i,"").trim(),n}function x(t,a=!1){var e,o;if(!t||t===g)return!1;g=t;try{navigator.clipboard.writeText(t)}catch{}return typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)&&chrome.storage.local.set({swayam_chatgpt_sync:t,swayam_chatgpt_timestamp:Date.now()}),u(a?"⚡ Auto-Synced! Redirecting to SWAYAM...":"✓ Sent! Redirecting to SWAYAM...","#065f46","#d1fae5"),typeof chrome<"u"&&((o=chrome.runtime)!=null&&o.sendMessage)&&chrome.storage.local.get(["swayam_pilot_context"],s=>{const i=s==null?void 0:s.swayam_pilot_context;chrome.runtime.sendMessage({type:"CHATGPT_SOLVE_COMPLETE",answersText:t,swayamTabId:i==null?void 0:i.tabId,swayamUrl:i==null?void 0:i.url},r=>{r!=null&&r.success&&u("✓ Switched to SWAYAM tab!","#065f46","#d1fae5")})}),c&&(c.textContent="✓ Sent! Returning to Swayam...",c.style.background="#10b981",c.style.color="#ffffff"),setTimeout(()=>{var i;typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)&&chrome.storage.local.set({autoPilotActive:!1});const s=document.getElementById("swayam404-chatgpt-badge");s&&(s.style.opacity="0",s.style.transition="opacity 0.4s ease",setTimeout(()=>s.remove(),400))},4500),!0}function P(){if(f)return;f=!0;let t=!1,a=0;const n=setInterval(()=>{if(a++,!!document.querySelector('button[data-testid="stop-button"], button[aria-label*="Stop"], button[aria-label*="stop"], [data-is-streaming="true"], [class*="result-streaming"]'))t=!0,u("⏳ AI Generating Answers...","#2563eb","#dbeafe");else if(t||a>=3){const o=b();if(o&&(o.includes("{")||o.includes("[")||o.includes('"question"'))){x(o,!0),clearInterval(n),f=!1;return}}a>120&&(clearInterval(n),f=!1,u("⚪ Ready","#1a1a1a","#f5f0e8"))},1500)}function w(){var t;typeof chrome>"u"||!((t=chrome.storage)!=null&&t.local)||chrome.storage.local.get(["pendingChatGptPrompt"],a=>{const n=a==null?void 0:a.pendingChatGptPrompt;if(!n)return;u("⚡ Auto-Pilot: Inserting prompt...","#1a1a1a","#ffcc00");let e=0;const o=setInterval(async()=>{e++,y()?(clearInterval(o),chrome.storage.local.remove(["pendingChatGptPrompt"]),await h(n,!0)):e>30&&(clearInterval(o),u("⚠️ Could not locate chat input","#b91c1c","#fee2e2"))},400)})}function T(){if(document.getElementById("swayam404-chatgpt-badge")||!document.body)return;const a=window.location.hostname.includes("claude.ai")?"Claude Web":"ChatGPT Web",n=document.createElement("div");n.id="swayam404-chatgpt-badge",n.style.cssText=`
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 9999999;
      background: #f5f0e8;
      border: 2px solid #1a1a1a;
      box-shadow: 4px 4px 0px #1a1a1a;
      padding: 12px 14px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      max-width: 290px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      box-sizing: border-box;
    `;const e=document.createElement("div");e.style.cssText=`
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1.5px solid #1a1a1a;
      padding-bottom: 6px;
    `;const o=document.createElement("div");o.style.cssText=`
      font-weight: 800;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #1a1a1a;
      display: flex;
      align-items: center;
      gap: 6px;
    `,o.innerHTML=`<span style="width:7px;height:7px;background:#ffcc00;display:inline-block;border:1px solid #1a1a1a"></span>SWAYAM 404 • ${a}`;const s=document.createElement("button");s.textContent="✕",s.style.cssText=`
      background: none;
      border: none;
      font-weight: 800;
      cursor: pointer;
      font-size: 11px;
      color: #1a1a1a;
      padding: 2px 4px;
    `,s.onclick=()=>{var r;typeof window<"u"&&window.sessionStorage&&window.sessionStorage.setItem("swayam404_badge_dismissed","true"),typeof chrome<"u"&&((r=chrome.storage)!=null&&r.local)&&(chrome.storage.local.set({autoPilotActive:!1}),chrome.storage.local.remove(["pendingChatGptPrompt"])),n.remove()},e.appendChild(o),e.appendChild(s),n.appendChild(e),d=document.createElement("div"),d.style.cssText=`
      font-size: 10px;
      font-weight: 700;
      padding: 4px 8px;
      border: 1px solid #1a1a1a;
      background: #ffffff;
      color: #1a1a1a;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      display: flex;
      align-items: center;
      gap: 5px;
    `,d.textContent="⚡ Auto-Pilot Ready",n.appendChild(d);const i=document.createElement("div");i.style.cssText="display: flex; flex-direction: column; gap: 6px;",l=document.createElement("button"),l.textContent="📋 Insert Swayam Questions",l.style.cssText=`
      background: #1a1a1a;
      color: #ffffff;
      border: 1.5px solid #1a1a1a;
      font-weight: 700;
      font-size: 11px;
      padding: 7px 10px;
      cursor: pointer;
      text-transform: uppercase;
      box-shadow: 2px 2px 0px #1a1a1a;
      transition: background 0.15s ease;
    `,l.onclick=()=>{var r;typeof chrome<"u"&&((r=chrome.storage)!=null&&r.local)&&chrome.storage.local.get(["pendingChatGptPrompt"],async p=>{const v=p==null?void 0:p.pendingChatGptPrompt;if(!v){alert('No pending questions prompt found. Click "1-Click Auto-Solve" or "Copy Prompt" in Swayam404 first.');return}await h(v,!1),l.textContent="✓ Inserted! Press Enter",l.style.background="#10b981",setTimeout(()=>{l.textContent="📋 Insert Swayam Questions",l.style.background="#1a1a1a"},4e3)})},c=document.createElement("button"),c.textContent="⚡ Send Answers to Swayam404",c.style.cssText=`
      background: #ffcc00;
      color: #1a1a1a;
      border: 1.5px solid #1a1a1a;
      font-weight: 800;
      font-size: 11px;
      padding: 7px 10px;
      cursor: pointer;
      text-transform: uppercase;
      box-shadow: 2px 2px 0px #1a1a1a;
      transition: background 0.15s ease;
    `,c.onclick=()=>{const r=b();if(!r){alert("No AI responses found on page yet. Please ensure ChatGPT has completed generating answers.");return}x(r,!1)},i.appendChild(l),i.appendChild(c),n.appendChild(i),document.body.appendChild(n),w()}function I(t){var a,n;if(typeof window<"u"&&((a=window.sessionStorage)==null?void 0:a.getItem("swayam404_badge_dismissed"))==="true"||typeof chrome>"u"||!((n=chrome.storage)!=null&&n.local))return t(!1);chrome.storage.local.get(["pendingChatGptPrompt","autoPilotActive","swayam_pilot_context"],e=>{var p;const o=!!(e!=null&&e.pendingChatGptPrompt),s=!!(e!=null&&e.autoPilotActive),i=((p=e==null?void 0:e.swayam_pilot_context)==null?void 0:p.timestamp)||0,r=i>0&&Date.now()-i<900*1e3;t(o||s&&r)})}function S(){I(t=>{if(t)T();else{const a=document.getElementById("swayam404-chatgpt-badge");a&&a.remove()}})}typeof chrome<"u"&&((C=chrome.storage)!=null&&C.onChanged)&&chrome.storage.onChanged.addListener((t,a)=>{var n,e;if(a==="local"){if((n=t.pendingChatGptPrompt)!=null&&n.newValue||t.autoPilotActive&&t.autoPilotActive.newValue===!0)typeof window<"u"&&window.sessionStorage&&window.sessionStorage.removeItem("swayam404_badge_dismissed"),S(),w();else if(t.autoPilotActive&&t.autoPilotActive.newValue===!1&&!((e=t.pendingChatGptPrompt)!=null&&e.newValue)){const o=document.getElementById("swayam404-chatgpt-badge");o&&o.remove()}}}),setTimeout(S,600)})()})();
