const U = /^(?:question\s*\d+|q\s*\.?\s*\d+|\d+)\s*[:.)-]\s*/i;
function _(n) {
  if (!n) return "";
  let t = n.trim();
  return t = t.replace(U, ""), t = t.replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').replace(/[\u2013\u2014]/g, "-").replace(/\u00A0/g, " "), t = t.toLowerCase(), t = t.replace(/_{2,}/g, "_").replace(/-{2,}/g, "-"), t = t.replace(/\s+/g, " "), t = t.replace(/[?:.]+(["']?)$/, "$1"), t = t.replace(/["']$/, ""), t = t.replace(/^["']/, ""), t = t.replace(/[?:.]+$/, ""), t.trim();
}
const s = {
  COURSES: "swayam404_courses_v1",
  QUESTIONS: "swayam404_questions_v1",
  SELECTED_COURSE_ID: "swayam404_selected_course_v1",
  SETTINGS: "swayam404_settings_v1",
  COURSE_MAPPINGS: "swayam404_course_mappings_v1",
  TASK_QUEUES: "swayam404_task_queues_v1",
  CHECKPOINTS: "swayam404_checkpoints_v1",
  COURSE_MATERIALS: "swayam404_course_materials_v1",
  ACTIVE_SCAN_SESSION: "swayam404_active_scan_session_v1",
  SCAN_HISTORY: "swayam404_scan_history_v1",
  KB_MANIFEST: "swayam404_kb_manifest_v1",
  KB_COURSE_PACKS: "swayam404_kb_course_packs_v1",
  KB_METADATA: "swayam404_kb_metadata_v1",
  KB_CONTRIBUTION_PROPOSALS: "swayam404_kb_proposals_v1"
}, m = [
  {
    id: "course-econ-101",
    name: "Economics (Common Course)",
    externalCourseId: "SWAYAM-ECON-CORE",
    description: "Shared core course for micro/macroeconomics assignments",
    isDefault: !0,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "course-ent-201",
    name: "Entrepreneurship (Minor Course)",
    externalCourseId: "SWAYAM-ENTR-MINOR",
    description: "Specialized minor course in startup mechanics & venture creation",
    isDefault: !1,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  }
], y = [
  {
    id: "map-econ-default",
    portalCourseTitle: "Principles of Economics",
    localCourseId: "course-econ-101",
    externalCourseId: "SWAYAM-ECON-CORE",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "map-ent-default",
    portalCourseTitle: "Entrepreneurship & Venture Initiation",
    localCourseId: "course-ent-201",
    externalCourseId: "SWAYAM-ENTR-MINOR",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  }
], R = {
  theme: "dark",
  selectedCourseId: "course-econ-101",
  autoScanOnLoad: !1,
  aiAssistedReviewEnabled: !1,
  aiProvider: "gemini",
  aiModel: "gemini-1.5-flash",
  grokModel: "grok-2-latest",
  openaiModel: "gpt-4o-mini",
  enableProviderFallback: !0,
  autoPopulateExactVerified: !1,
  // Explicit opt-in required for auto-fill
  autoApplyHighConfidence: !1,
  knowledgeBaseEnabled: !1,
  knowledgeBaseRepoUrl: ""
};
function v() {
  var n;
  return typeof chrome < "u" && !!((n = chrome == null ? void 0 : chrome.storage) != null && n.local);
}
const N = {};
async function w(n, t) {
  if (v())
    return new Promise((e) => {
      chrome.storage.local.get([n], (a) => {
        if (chrome.runtime.lastError) {
          console.warn(`Storage get error for ${n}:`, chrome.runtime.lastError), e(t);
          return;
        }
        a && a[n] !== void 0 ? e(a[n]) : e(t);
      });
    });
  if (typeof window < "u" && window.localStorage)
    try {
      const e = window.localStorage.getItem(n);
      if (e !== null)
        return JSON.parse(e);
    } catch (e) {
      console.warn(`localStorage read error for ${n}:`, e);
    }
  return N[n] ?? t;
}
async function c(n, t) {
  if (v())
    return new Promise((e, a) => {
      chrome.storage.local.set({ [n]: t }, () => {
        chrome.runtime.lastError ? a(chrome.runtime.lastError) : e();
      });
    });
  if (typeof window < "u" && window.localStorage)
    try {
      window.localStorage.setItem(n, JSON.stringify(t));
    } catch (e) {
      console.warn(`localStorage write error for ${n}:`, e);
    }
  N[n] = t;
}
class x {
  /**
   * Initializes default course seeds if none exist
   */
  static async initDefaults() {
    (await w(s.COURSES, [])).length === 0 && await c(s.COURSES, m), await w(s.SELECTED_COURSE_ID, "") || await c(s.SELECTED_COURSE_ID, m[0].id), (await w(s.COURSE_MAPPINGS, [])).length === 0 && await c(s.COURSE_MAPPINGS, y);
  }
  static async getCourses() {
    const t = await w(s.COURSES, []);
    return t.length === 0 ? (await this.initDefaults(), m) : t;
  }
  static async saveCourse(t) {
    const e = await this.getCourses(), a = e.findIndex((l) => l.id === t.id), o = [...e], i = (/* @__PURE__ */ new Date()).toISOString();
    a >= 0 ? o[a] = { ...t, updatedAt: i } : o.push({ ...t, createdAt: i, updatedAt: i }), await c(s.COURSES, o);
  }
  static async deleteCourse(t) {
    const a = (await this.getCourses()).filter((p) => p.id !== t);
    await c(s.COURSES, a);
    const i = (await this.getQuestions()).filter((p) => p.courseId !== t);
    await c(s.QUESTIONS, i), await this.getSelectedCourseId() === t && a.length > 0 && await this.setSelectedCourseId(a[0].id);
  }
  static async getSelectedCourseId() {
    var e;
    const t = await w(s.SELECTED_COURSE_ID, "");
    return t || (((e = (await this.getCourses())[0]) == null ? void 0 : e.id) ?? "course-econ-101");
  }
  static async setSelectedCourseId(t) {
    await c(s.SELECTED_COURSE_ID, t);
  }
  static async getQuestions(t) {
    const e = await w(s.QUESTIONS, []);
    return t ? e.filter((a) => a.courseId === t) : e;
  }
  static async saveQuestion(t) {
    const e = await this.getQuestions(), a = (/* @__PURE__ */ new Date()).toISOString(), o = e.findIndex((l) => l.id === t.id), i = [...e];
    o >= 0 ? i[o] = { ...t, updatedAt: a } : i.push({ ...t, createdAt: a, updatedAt: a }), await c(s.QUESTIONS, i);
  }
  static async saveQuestions(t) {
    const e = await this.getQuestions(), a = new Map(e.map((i) => [i.id, i])), o = (/* @__PURE__ */ new Date()).toISOString();
    for (const i of t)
      a.set(i.id, {
        ...i,
        updatedAt: o,
        createdAt: i.createdAt || o
      });
    await c(s.QUESTIONS, Array.from(a.values()));
  }
  static async deleteQuestion(t) {
    const e = await this.getQuestions();
    await c(s.QUESTIONS, e.filter((a) => a.id !== t));
  }
  static async replaceQuestionsForCourse(t, e) {
    const o = (await this.getQuestions()).filter((l) => l.courseId !== t), i = e.map((l) => ({
      ...l,
      courseId: t,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }));
    await c(s.QUESTIONS, [...o, ...i]);
  }
  static async getSettings() {
    const t = await w(s.SETTINGS, R);
    return t && !t.aiModel && (t.aiModel = "gemini-1.5-flash"), t && !t.grokModel && (t.grokModel = "grok-2-latest"), t && t.enableProviderFallback === void 0 && (t.enableProviderFallback = !0), t;
  }
  static async saveSettings(t) {
    const e = await this.getSettings();
    await c(s.SETTINGS, { ...e, ...t });
  }
  static async exportAll() {
    const t = await this.getCourses(), e = await this.getQuestions();
    return {
      version: "1.0.0",
      app: "swayam404",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      courses: t,
      questions: e
    };
  }
  static async exportCourse(t) {
    const a = (await this.getCourses()).find((i) => i.id === t), o = await this.getQuestions(t);
    return {
      version: "1.0.0",
      app: "swayam404",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      courses: a ? [a] : [],
      questions: o
    };
  }
  static async clearAll() {
    await c(s.COURSES, []), await c(s.QUESTIONS, []), await c(s.COURSE_MAPPINGS, []), await c(s.TASK_QUEUES, {}), await c(s.CHECKPOINTS, {}), await c(s.KB_MANIFEST, null), await c(s.KB_COURSE_PACKS, {}), await c(s.KB_METADATA, null);
  }
  // --- Course Identity Mapping ---
  static async getCourseMappings() {
    const t = await w(s.COURSE_MAPPINGS, []);
    return t.length === 0 ? (await c(s.COURSE_MAPPINGS, y), y) : t;
  }
  static async saveCourseMapping(t) {
    const e = await this.getCourseMappings(), a = e.findIndex((l) => l.id === t.id), o = [...e], i = (/* @__PURE__ */ new Date()).toISOString();
    a >= 0 ? o[a] = { ...t, updatedAt: i } : o.push({ ...t, createdAt: i, updatedAt: i }), await c(s.COURSE_MAPPINGS, o);
  }
  static async deleteCourseMapping(t) {
    const e = await this.getCourseMappings();
    await c(s.COURSE_MAPPINGS, e.filter((a) => a.id !== t));
  }
  static async findMappingForPortalCourse(t, e) {
    if (!t) return;
    const a = await this.getCourseMappings(), o = t.trim().toLowerCase();
    if (e) {
      const u = a.find(
        (r) => r.externalCourseId && r.externalCourseId.toLowerCase() === e.toLowerCase()
      );
      if (u) return u;
    }
    const i = a.find(
      (u) => u.portalCourseTitle.trim().toLowerCase() === o
    );
    if (i) return i;
    const l = a.find((u) => {
      const r = u.portalCourseTitle.toLowerCase();
      return o.includes(r) || r.includes(o);
    });
    if (l) return l;
    const p = o.split(/[\s\-–—:,()]+/).filter((u) => u.length >= 5);
    return a.find((u) => {
      const r = u.portalCourseTitle.toLowerCase().split(/[\s\-–—:,()]+/);
      return p.some((S) => r.includes(S));
    });
  }
  // --- Task Queue Management ---
  static async getTasksForCourse(t) {
    return (await w(s.TASK_QUEUES, {}))[t] || [];
  }
  static async saveTasksForCourse(t, e) {
    const a = await w(s.TASK_QUEUES, {});
    a[t] = e, await c(s.TASK_QUEUES, a);
  }
  static async updateTaskStatus(t, e, a) {
    const i = (await this.getTasksForCourse(t)).map((l) => l.id === e ? { ...l, ...a } : l);
    await this.saveTasksForCourse(t, i);
  }
  static async clearTasksForCourse(t) {
    const e = await w(s.TASK_QUEUES, {});
    delete e[t], await c(s.TASK_QUEUES, e);
  }
  // --- Workflow Checkpoints ---
  static async getCheckpoint(t) {
    return (await w(s.CHECKPOINTS, {}))[t];
  }
  static async saveCheckpoint(t) {
    const e = await w(s.CHECKPOINTS, {});
    e[t.courseId] = { ...t, updatedAt: (/* @__PURE__ */ new Date()).toISOString() }, await c(s.CHECKPOINTS, e);
  }
  static async clearCheckpoint(t) {
    const e = await w(s.CHECKPOINTS, {});
    delete e[t], await c(s.CHECKPOINTS, e);
  }
  // --- Answer-Bank Readiness Assessment ---
  static async assessCourseReadiness(t) {
    const a = (await this.getCourses()).find((f) => f.id === t), o = a ? a.name : "Unknown Course", i = await this.getQuestions(t), l = i.length;
    let p = 0, u = 0, r = 0, S = 0, A = 0, d = 0, T = 0;
    for (const f of i) {
      const P = f.correctOptions && f.correctOptions.length > 0, M = f.answerText && f.answerText.trim() !== "";
      (P || M) && p++, f.reviewStatus === "portal-confirmed" ? (r++, u++) : f.reviewStatus === "student-reviewed" || f.reviewStatus === "verified" ? (S++, u++) : f.reviewStatus === "ai-suggested" ? A++ : f.reviewStatus === "conflicted" && d++, (f.source && f.source.toLowerCase().includes("sample") || f.id && f.id.startsWith("sample-")) && T++;
    }
    const g = await this.getSettings(), E = !!g.aiAssistedReviewEnabled && (g.aiProvider === "grok" ? !!(g.grokApiKey || g.aiApiKey) : !!g.aiApiKey), I = l > 0 && T >= l * 0.8, h = p > 0 || E;
    let C = "", O;
    return l === 0 ? E ? C = `AI Ready: No historical answers saved yet. ${g.aiProvider === "grok" ? "xAI Grok" : "Google Gemini"} & course materials active for new questions.` : C = "No historical answers are saved for this course yet (empty bank). Swayam404 will use available course materials and your configured AI provider." : p === 0 ? E ? C = "Stored questions lack verified answers. Active AI provider will assist with question analysis." : C = "Stored questions have no recorded answers. Mark answers as verified or configure AI in Settings." : I ? (O = "Current answer bank contains fictional sample data. Not verified for graded submissions.", C = `Ready for test workflow (${u} verified answers). Sample data warning active.`) : C = `Ready: ${u} verified answers (${r} portal-confirmed, ${S} student-reviewed) in bank.`, {
      courseId: t,
      courseName: o,
      totalStoredQuestions: l,
      usableAnswersCount: p,
      verifiedAnswersCount: u,
      portalConfirmedCount: r,
      studentReviewedCount: S,
      aiSuggestedCount: A,
      conflictedCount: d,
      isSampleData: I,
      sampleDataWarning: O,
      isReadyForPrep: h,
      readinessReason: C
    };
  }
  // --- Course Material (Context Retrieval) ---
  static async getCourseMaterials(t) {
    const e = await w(s.COURSE_MATERIALS, []);
    return t ? e.filter((a) => a.courseId === t) : e;
  }
  static async saveCourseMaterial(t) {
    const e = await this.getCourseMaterials(), a = e.findIndex((l) => l.id === t.id), o = [...e], i = (/* @__PURE__ */ new Date()).toISOString();
    a >= 0 ? o[a] = { ...t, updatedAt: i } : o.push({ ...t, createdAt: i, updatedAt: i }), await c(s.COURSE_MATERIALS, o);
  }
  static async deleteCourseMaterial(t) {
    const e = await this.getCourseMaterials();
    await c(
      s.COURSE_MATERIALS,
      e.filter((a) => a.id !== t)
    );
  }
  // --- Historical Answer Capture with Deduplication & Conflict Detection ---
  static async saveCapturedQuestions(t, e) {
    const a = await this.getQuestions(), o = (/* @__PURE__ */ new Date()).toISOString();
    let i = 0, l = 0, p = 0;
    const u = [...a];
    for (const r of t) {
      if (!r.isSelectedForSave) continue;
      const S = _(r.questionText), A = u.findIndex(
        (d) => d.courseId === e && _(d.questionText) === S
      );
      if (A >= 0) {
        const d = u[A], T = d.correctOptions || (d.answerText ? [d.answerText] : []), g = r.acceptedAnswers, E = new Set(T.map((C) => _(C))), I = new Set(g.map((C) => _(C)));
        E.size === I.size && [...E].every((C) => I.has(C)) ? (u[A] = {
          ...d,
          portalCourseTitle: r.portalCourseTitle || d.portalCourseTitle,
          externalCourseId: r.externalCourseId || d.externalCourseId,
          assignmentTitle: r.assignmentTitle || d.assignmentTitle,
          unitTitle: r.unitTitle || d.unitTitle,
          explanation: r.explanation || d.explanation,
          reviewStatus: r.verificationStatus,
          verificationSource: r.verificationSource,
          capturedAt: o,
          updatedAt: o
        }, p++) : (u[A] = {
          ...d,
          correctOptions: Array.from(/* @__PURE__ */ new Set([...T, ...g])),
          explanation: `[CONFLICT: Previously recorded (${T.join(", ")}), but newly captured (${g.join(", ")}). Manual review required.] ${r.explanation || d.explanation || ""}`.trim(),
          reviewStatus: "conflicted",
          verificationSource: "conflict_detected",
          capturedAt: o,
          updatedAt: o
        }, l++);
      } else {
        const d = {
          id: `captured-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          courseId: e,
          portalCourseTitle: r.portalCourseTitle,
          externalCourseId: r.externalCourseId,
          assignmentTitle: r.assignmentTitle,
          unitTitle: r.unitTitle,
          questionText: r.questionText,
          normalizedText: S,
          questionType: r.questionType,
          options: r.options,
          correctOptions: r.acceptedAnswers,
          answerText: r.acceptedAnswers.length === 1 ? r.acceptedAnswers[0] : void 0,
          explanation: r.explanation,
          reviewStatus: r.verificationStatus,
          verificationSource: r.verificationSource,
          source: r.assignmentTitle || "Captured Submitted Assignment",
          createdAt: o,
          updatedAt: o,
          capturedAt: o
        };
        u.push(d), i++;
      }
    }
    return await c(s.QUESTIONS, u), { saved: i, conflicts: l, duplicates: p };
  }
  // --- Active Scan Session Persistence (Prevents Reset on Tab Switch) ---
  static async getActiveScanSession() {
    return await w(s.ACTIVE_SCAN_SESSION, null);
  }
  static async saveActiveScanSession(t) {
    await c(s.ACTIVE_SCAN_SESSION, t);
  }
  static async clearActiveScanSession() {
    await c(s.ACTIVE_SCAN_SESSION, null);
  }
  // --- Assignment Scan History ---
  static async getScanHistory() {
    return await w(s.SCAN_HISTORY, []);
  }
  static async saveScanHistory(t) {
    const a = (await this.getScanHistory()).filter(
      (i) => !(t.url && i.url === t.url || i.assignmentTitle && i.assignmentTitle === t.assignmentTitle)
    ), o = [t, ...a].slice(0, 20);
    await c(s.SCAN_HISTORY, o);
  }
  static async deleteScanHistoryItem(t) {
    const e = await this.getScanHistory();
    await c(
      s.SCAN_HISTORY,
      e.filter((a) => a.id !== t)
    );
  }
  static async clearScanHistory() {
    await c(s.SCAN_HISTORY, []);
  }
  // --- Shared Knowledge Base Caching ---
  static async getKnowledgeManifest() {
    return await w(s.KB_MANIFEST, null);
  }
  static async saveKnowledgeManifest(t) {
    await c(s.KB_MANIFEST, t);
  }
  static async getKnowledgeCoursePacks() {
    return await w(s.KB_COURSE_PACKS, {});
  }
  static async saveKnowledgeCoursePacks(t) {
    await c(s.KB_COURSE_PACKS, t);
  }
  static async getKnowledgeMetadata() {
    return await w(s.KB_METADATA, null);
  }
  static async saveKnowledgeMetadata(t) {
    await c(s.KB_METADATA, t);
  }
  static async clearKnowledgeCache() {
    await c(s.KB_MANIFEST, null), await c(s.KB_COURSE_PACKS, {}), await c(s.KB_METADATA, null);
  }
  // --- Community Knowledge Contribution Proposals ---
  static async getContributionProposals() {
    return await w(s.KB_CONTRIBUTION_PROPOSALS, []);
  }
  static async saveContributionProposal(t) {
    const e = await this.getContributionProposals(), a = e.findIndex((o) => o.proposalId === t.proposalId);
    a >= 0 ? e[a] = t : e.unshift(t), await c(s.KB_CONTRIBUTION_PROPOSALS, e);
  }
  static async deleteContributionProposal(t) {
    const e = await this.getContributionProposals();
    await c(
      s.KB_CONTRIBUTION_PROPOSALS,
      e.filter((a) => a.proposalId !== t)
    );
  }
}
console.log("[swayam404] Background service worker initialized.");
chrome.runtime.onInstalled.addListener(async (n) => {
  console.log("[swayam404] Extension installed/updated, reason:", n.reason);
  try {
    await x.initDefaults(), console.log("[swayam404] Default courses and settings initialized in storage.");
  } catch (t) {
    console.error("[swayam404] Error initializing defaults on install:", t);
  }
});
chrome.sidePanel && "setPanelBehavior" in chrome.sidePanel && chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !1 }).catch((n) => {
  console.warn("[swayam404] sidePanel.setPanelBehavior warning:", n);
});
chrome.runtime.onMessage.addListener((n, t, e) => {
  var a, o;
  if ((n == null ? void 0 : n.type) === "REGISTER_SWAYAM_TAB" || (n == null ? void 0 : n.type) === "SWAYAM_TAB_NAVIGATION") {
    const i = ((a = t.tab) == null ? void 0 : a.id) || n.tabId, l = ((o = t.tab) == null ? void 0 : o.url) || n.url;
    return i && l && (chrome.storage.local.set({
      swayam_pilot_context: {
        tabId: i,
        url: l,
        detectedWeek: n.detectedWeek,
        detectedWeekNumber: n.detectedWeekNumber,
        detectedAssignmentTitle: n.detectedAssignmentTitle,
        courseTitle: n.courseTitle,
        timestamp: Date.now()
      }
    }), chrome.runtime.sendMessage({
      type: "SWAYAM_PORTAL_UPDATED",
      tabId: i,
      url: l,
      detectedWeek: n.detectedWeek,
      detectedWeekNumber: n.detectedWeekNumber,
      detectedAssignmentTitle: n.detectedAssignmentTitle,
      courseTitle: n.courseTitle
    }).catch(() => {
    }), e({ success: !0, tabId: i })), !1;
  }
  return (n == null ? void 0 : n.type) === "CHATGPT_SOLVE_COMPLETE" ? ((async () => {
    var i, l, p, u;
    try {
      const r = n.answersText;
      r && await chrome.storage.local.set({
        swayam_chatgpt_sync: r,
        swayam_chatgpt_timestamp: Date.now()
      });
      let S = null;
      const A = n.swayamTabId;
      if (A && typeof ((i = chrome.tabs) == null ? void 0 : i.get) == "function")
        try {
          S = await chrome.tabs.get(A);
        } catch {
          S = null;
        }
      if (!S && typeof ((l = chrome.tabs) == null ? void 0 : l.query) == "function") {
        const d = await chrome.tabs.query({
          url: [
            "https://*.swayam2.ac.in/*",
            "https://swayam2.ac.in/*",
            "https://*.swayam.gov.in/*",
            "https://swayam.gov.in/*",
            "https://*.nptel.ac.in/*",
            "https://nptel.ac.in/*",
            "http://localhost/*",
            "http://127.0.0.1/*"
          ]
        });
        d.length > 0 && (S = d[0]);
      }
      if (S != null && S.id)
        await chrome.tabs.update(S.id, { active: !0 }), S.windowId && typeof ((p = chrome.windows) == null ? void 0 : p.update) == "function" && await chrome.windows.update(S.windowId, { focused: !0 }), r && chrome.tabs.sendMessage(S.id, {
          type: "AUTO_APPLY_ANSWERS",
          answersText: r
        }).catch(() => {
        }), e({ success: !0, switchedTabId: S.id });
      else if (n.swayamUrl && typeof ((u = chrome.tabs) == null ? void 0 : u.create) == "function") {
        const d = await chrome.tabs.create({ url: n.swayamUrl, active: !0 });
        e({ success: !0, switchedTabId: d.id });
      } else
        e({ success: !1, reason: "No SWAYAM tab found" });
    } catch (r) {
      console.error("[swayam404] Error during CHATGPT_SOLVE_COMPLETE redirection:", r), e({ success: !1, error: r.message });
    }
  })(), !0) : !1;
});
