# Swayam404 Desktop Installer & Chrome Extension (Windows)

## Quick Start on Windows:
Method A (Direct Load - Fastest):
1. Open Google Chrome (or Brave / Edge) to: chrome://extensions
2. Toggle "Developer mode" ON (top right corner).
3. Click "Load unpacked" (top left).
4. Select the "dist" folder included in this package.
5. The Swayam404 extension is now active and ready to use!

Method B (Installer Dashboard Script):
1. Double-click "Swayam404-Installer-Windows.bat".
2. If Windows SmartScreen displays "Windows protected your PC":
   - Click "More info" -> Click "Run anyway".
3. The installer dashboard will automatically launch in your browser.
4. Follow the on-screen instructions.

All future updates will be applied automatically from GitHub or local releases with one click!
