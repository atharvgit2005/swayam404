#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
APP_SRC="$DIR/Swayam404 Installer.app"
APP_DEST="/Applications/Swayam404 Installer.app"

echo "========================================================"
echo "⚡ Swayam404 Automatic 1-Click Installer"
echo "========================================================"
echo "1. Installing Swayam404 to /Applications..."
rm -rf "$APP_DEST" 2>/dev/null
cp -R "$APP_SRC" "/Applications/"

echo "2. Authorizing application with macOS Security..."
xattr -cr "$APP_DEST" 2>/dev/null || true

echo "3. Launching Swayam404 Installer..."
open "$APP_DEST"
echo "========================================================"
echo "🎉 Installation complete! Dashboard window opened."
echo "========================================================"
exit 0
