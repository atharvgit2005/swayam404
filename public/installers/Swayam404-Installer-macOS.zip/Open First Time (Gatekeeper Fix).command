#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
APP_NAME="Swayam404 Installer.app"

echo "========================================================"
echo "⚡ Swayam404 macOS Gatekeeper Security Helper"
echo "========================================================"
echo "Clearing macOS quarantine attribute..."

xattr -d com.apple.quarantine "$DIR/$APP_NAME" 2>/dev/null || xattr -cr "$DIR/$APP_NAME" 2>/dev/null
xattr -d com.apple.quarantine "/Applications/$APP_NAME" 2>/dev/null || xattr -cr "/Applications/$APP_NAME" 2>/dev/null

echo "✅ Quarantine cleared! Launching Swayam404 Installer..."
if [ -d "/Applications/$APP_NAME" ]; then
    open "/Applications/$APP_NAME"
else
    open "$DIR/$APP_NAME"
fi
exit 0
