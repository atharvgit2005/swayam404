# Swayam404 Desktop Installer (macOS)

============================================================
HOW TO INSTALL:
============================================================
1. Drag "Swayam404 Installer" into the "Applications" folder.
2. Open "Applications" and double-click "Swayam404 Installer".

============================================================
IF macOS BLOCKS WITH "Apple could not verify..."
============================================================
Because this is an open-source tool built by students without a $99/yr Apple certificate,
macOS Gatekeeper protects your Mac. Choose ANY of these 3 easy ways:

OPTION A (Fastest 1-Click):
• Double-click "Open First Time (Gatekeeper Fix).command" in this window!

OPTION B (Standard macOS Right-Click):
• Right-click (or Control-click) "Swayam404 Installer"
• Click "Open"
• Click "Open" in the prompt.

OPTION C (System Settings):
• Open System Settings > Privacy & Security
• Scroll down to the "Security" section
• Click "Open Anyway" next to Swayam404 Installer!
============================================================
