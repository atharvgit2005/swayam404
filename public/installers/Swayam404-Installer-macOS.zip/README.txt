# Swayam404 Desktop Installer & Chrome Extension (macOS)

## Quick Start on Mac:
Method A (Direct Load - Fastest):
1. Open Google Chrome (or Brave / Edge / Arc) to: chrome://extensions
2. Toggle "Developer mode" ON (top right corner).
3. Click "Load unpacked" (top left).
4. Select the "dist" folder included in this package.
5. The Swayam404 extension is now active and ready to use!

Method B (Installer Dashboard App):
1. Double-click "Start-Installer.command" or "Swayam404 Installer.app".
2. If macOS displays a Gatekeeper security warning:
   - Right-click "Start-Installer.command" -> Open -> Click "Open"
3. The dashboard opens at http://127.0.0.1:52410 where you can manage updates and check status.

All updates and releases can be applied with one click!
