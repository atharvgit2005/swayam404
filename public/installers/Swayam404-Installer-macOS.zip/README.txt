# Swayam404 Desktop Installer (macOS)

============================================================
HOW TO INSTALL:
============================================================
OPTION 1 (Easiest — 1-Click):
• Double-click "🚀 1-Click Install to Applications.command"
  (or "⚠️ IF BLOCKED BY APPLE - CLICK HERE.command")!
  It will automatically copy the app to /Applications and launch it.

OPTION 2 (Standard macOS Drag & Drop):
1. Drag "Swayam404 Installer" into the "Applications" folder right next to it.
2. Open your "Applications" folder and double-click "Swayam404 Installer".

============================================================
IF macOS BLOCKS WITH "Apple could not verify..."
============================================================
Because this is an open-source tool built by students:
• Method A: Double-click "⚠️ IF BLOCKED BY APPLE - CLICK HERE.command" (opens Settings for you!)
• Method B: Right-click (or Control-click) Swayam404 Installer ➔ Open ➔ Click "Open"
• Method C: Open System Settings > Privacy & Security > scroll to "Security" > Click "Open Anyway"
============================================================
