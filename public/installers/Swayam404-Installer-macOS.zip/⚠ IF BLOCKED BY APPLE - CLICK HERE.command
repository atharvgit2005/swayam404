#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
APP_SRC="$DIR/Swayam404 Installer.app"
APP_DEST="/Applications/Swayam404 Installer.app"

echo "========================================================"
echo "⚡ Swayam404 — macOS Security Guide & Auto-Approval"
echo "========================================================"
echo ""
echo "1. Installing Swayam404 into /Applications..."
if [ -d "$APP_SRC" ]; then
    rm -rf "$APP_DEST" 2>/dev/null
    cp -R "$APP_SRC" "/Applications/" 2>/dev/null
fi

echo "2. Clearing Gatekeeper quarantine restrictions..."
xattr -cr "$APP_DEST" 2>/dev/null || true

echo "3. Opening System Settings to Privacy & Security..."
open "x-apple.systempreferences:com.apple.preference.security"

echo ""
echo "========================================================"
echo "👉 WHAT TO DO IN SYSTEM SETTINGS (Right Now):"
echo "========================================================"
echo "1. The System Settings window is now open on your screen."
echo "2. Scroll down to the 'Security' section."
echo "3. Click the 'Open Anyway' button next to Swayam404 Installer."
echo "4. When prompted, click 'Open'!"
echo "========================================================"
echo ""
echo "Launching Swayam404 Installer..."
sleep 1
open "$APP_DEST" 2>/dev/null || true
exit 0
