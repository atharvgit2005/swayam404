const e = "1.0.0", t = "swayam404", s = "2026-03-01T10:00:00.000Z", n = "SAMPLE FICTIONAL DATA FOR TESTING - NOT VERIFIED EXAM MATERIAL", r = [{ id: "course-ent-201", name: "Entrepreneurship (Minor Course)", externalCourseId: "SWAYAM-ENTR-MINOR", description: "Specialized minor course in startup mechanics & venture creation" }], i = [{ id: "sample-ent-1", courseId: "course-ent-201", questionText: "What is the primary objective of building a Minimum Viable Product (MVP)?", questionType: "single-choice", options: ["To maximize immediate commercial sales revenue", "To accelerate validated learning with minimum resources", "To satisfy all enterprise feature requests upfront", "To bypass regulatory standards"], correctOptions: ["To accelerate validated learning with minimum resources"], explanation: "According to Lean Startup principles, an MVP aims to test fundamental business hypotheses quickly with the least effort.", reviewStatus: "verified", source: "Sample Entrepreneurship Question Bank" }, { id: "sample-ent-2", courseId: "course-ent-201", questionText: "What term describes the rate at which a new venture consumes its cash reserves before generating positive cash flow?", questionType: "single-choice", options: ["Churn rate", "Burn rate", "Discount rate", "Dilution rate"], correctOptions: ["Burn rate"], explanation: "Burn rate measures monthly net negative cash flow.", reviewStatus: "verified", source: "Sample Entrepreneurship Question Bank" }, { id: "sample-ent-3", courseId: "course-ent-201", questionText: "Which blocks are included in Osterwalder's Business Model Canvas?", questionType: "multiple-choice", options: ["Value Propositions", "Customer Segments", "Cost Structure", "Revenue Streams"], correctOptions: ["Value Propositions", "Customer Segments", "Cost Structure", "Revenue Streams"], explanation: "All four are key pillars among the 9 building blocks of the Business Model Canvas.", reviewStatus: "verified", source: "Sample Entrepreneurship Question Bank" }, { id: "sample-ent-4", courseId: "course-ent-201", questionText: "Bootstrapping refers to financing a company exclusively through external venture capital funds.", questionType: "true-false", options: ["True", "False"], correctOptions: ["False"], explanation: "Bootstrapping means self-funding a venture using personal savings and operational cash flow, without external equity funding.", reviewStatus: "verified", source: "Sample Entrepreneurship Question Bank" }, { id: "sample-ent-5", courseId: "course-ent-201", questionText: "What is the acronym for the metrics that assess cost to acquire a single customer?", questionType: "short-text", answerText: "CAC", explanation: "CAC stands for Customer Acquisition Cost.", reviewStatus: "verified", source: "Sample Entrepreneurship Question Bank" }], o = {
  version: e,
  app: t,
  exportedAt: s,
  note: n,
  courses: r,
  questions: i
};
export {
  t as app,
  r as courses,
  o as default,
  s as exportedAt,
  n as note,
  i as questions,
  e as version
};
