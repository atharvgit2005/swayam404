var Ee = Object.defineProperty;
var Ae = (n, e, t) => e in n ? Ee(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t;
var D = (n, e, t) => Ae(n, typeof e != "symbol" ? e + "" : e, t);
const Re = {
  enabled: !0,
  serverUrl: "http://127.0.0.1:52404"
}, Te = /^(?:question\s*\d+|q\s*\.?\s*\d+|\d+)\s*[:.)-]\s*/i;
function x(n) {
  if (!n) return "";
  let e = n.trim();
  return e = e.replace(Te, ""), e = e.replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').replace(/[\u2013\u2014]/g, "-").replace(/\u00A0/g, " "), e = e.toLowerCase(), e = e.replace(/_{2,}/g, "_").replace(/-{2,}/g, "-"), e = e.replace(/\s+/g, " "), e = e.replace(/[?:.]+(["']?)$/, "$1"), e = e.replace(/["']$/, ""), e = e.replace(/^["']/, ""), e = e.replace(/[?:.]+$/, ""), e.trim();
}
const p = {
  COURSES: "swayam404_courses_v1",
  QUESTIONS: "swayam404_questions_v1",
  SELECTED_COURSE_ID: "swayam404_selected_course_v1",
  SETTINGS: "swayam404_settings_v1",
  COURSE_MAPPINGS: "swayam404_course_mappings_v1",
  TASK_QUEUES: "swayam404_task_queues_v1",
  CHECKPOINTS: "swayam404_checkpoints_v1",
  COURSE_MATERIALS: "swayam404_course_materials_v1",
  ACTIVE_SCAN_SESSION: "swayam404_active_scan_session_v1",
  SCAN_HISTORY: "swayam404_scan_history_v1",
  KB_MANIFEST: "swayam404_kb_manifest_v1",
  KB_COURSE_PACKS: "swayam404_kb_course_packs_v1",
  KB_METADATA: "swayam404_kb_metadata_v1",
  KB_CONTRIBUTION_PROPOSALS: "swayam404_kb_proposals_v1",
  KB_UPDATE_STATE: "swayam404_kb_update_state_v1",
  EXTENSION_UPDATER_STATE: "swayam404_ext_updater_state_v1",
  LOCAL_UPDATER_CONFIG: "swayam404_local_updater_config_v1"
}, W = [
  {
    id: "course-econ-101",
    name: "Economics (Common Course)",
    externalCourseId: "SWAYAM-ECON-CORE",
    description: "Shared core course for micro/macroeconomics assignments",
    isDefault: !0,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "course-ent-201",
    name: "Entrepreneurship (Minor Course)",
    externalCourseId: "SWAYAM-ENTR-MINOR",
    description: "Specialized minor course in startup mechanics & venture creation",
    isDefault: !1,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  }
], z = [
  {
    id: "map-econ-default",
    portalCourseTitle: "Principles of Economics",
    localCourseId: "course-econ-101",
    externalCourseId: "SWAYAM-ECON-CORE",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "map-ent-default",
    portalCourseTitle: "Entrepreneurship & Venture Initiation",
    localCourseId: "course-ent-201",
    externalCourseId: "SWAYAM-ENTR-MINOR",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  }
], _e = {
  theme: "dark",
  selectedCourseId: "course-econ-101",
  autoScanOnLoad: !1,
  aiAssistedReviewEnabled: !1,
  aiProvider: "gemini",
  webAiProvider: "chatgpt",
  aiModel: "gemini-1.5-flash",
  grokModel: "grok-2-latest",
  openaiModel: "gpt-4o-mini",
  enableProviderFallback: !0,
  autoPopulateExactVerified: !1,
  // Explicit opt-in required for auto-fill
  autoApplyHighConfidence: !1,
  knowledgeBaseEnabled: !1,
  knowledgeBaseRepoUrl: ""
};
function ge() {
  var n;
  return typeof chrome < "u" && !!((n = chrome == null ? void 0 : chrome.storage) != null && n.local);
}
const we = {};
async function A(n, e) {
  if (ge())
    return new Promise((t) => {
      chrome.storage.local.get([n], (s) => {
        if (chrome.runtime.lastError) {
          console.warn(`Storage get error for ${n}:`, chrome.runtime.lastError), t(e);
          return;
        }
        s && s[n] !== void 0 ? t(s[n]) : t(e);
      });
    });
  if (typeof window < "u" && window.localStorage)
    try {
      const t = window.localStorage.getItem(n);
      if (t !== null)
        return JSON.parse(t);
    } catch (t) {
      console.warn(`localStorage read error for ${n}:`, t);
    }
  return we[n] ?? e;
}
async function m(n, e) {
  if (ge())
    return new Promise((t, s) => {
      chrome.storage.local.set({ [n]: e }, () => {
        chrome.runtime.lastError ? s(chrome.runtime.lastError) : t();
      });
    });
  if (typeof window < "u" && window.localStorage)
    try {
      window.localStorage.setItem(n, JSON.stringify(e));
    } catch (t) {
      console.warn(`localStorage write error for ${n}:`, t);
    }
  we[n] = e;
}
class T {
  /**
   * Initializes default course seeds if none exist
   */
  static async initDefaults() {
    (await A(p.COURSES, [])).length === 0 && await m(p.COURSES, W), await A(p.SELECTED_COURSE_ID, "") || await m(p.SELECTED_COURSE_ID, W[0].id), (await A(p.COURSE_MAPPINGS, [])).length === 0 && await m(p.COURSE_MAPPINGS, z);
  }
  static async getCourses() {
    const e = await A(p.COURSES, []);
    return e.length === 0 ? (await this.initDefaults(), W) : e;
  }
  static async saveCourse(e) {
    const t = await this.getCourses(), s = t.findIndex((c) => c.id === e.id), a = [...t], o = (/* @__PURE__ */ new Date()).toISOString();
    s >= 0 ? a[s] = { ...e, updatedAt: o } : a.push({ ...e, createdAt: o, updatedAt: o }), await m(p.COURSES, a);
  }
  static async deleteCourse(e) {
    const s = (await this.getCourses()).filter((l) => l.id !== e);
    await m(p.COURSES, s);
    const o = (await this.getQuestions()).filter((l) => l.courseId !== e);
    await m(p.QUESTIONS, o), await this.getSelectedCourseId() === e && s.length > 0 && await this.setSelectedCourseId(s[0].id);
  }
  static async getSelectedCourseId() {
    var t;
    const e = await A(p.SELECTED_COURSE_ID, "");
    return e || (((t = (await this.getCourses())[0]) == null ? void 0 : t.id) ?? "course-econ-101");
  }
  static async setSelectedCourseId(e) {
    await m(p.SELECTED_COURSE_ID, e);
  }
  static async getQuestions(e) {
    const t = await A(p.QUESTIONS, []);
    return e ? t.filter((s) => s.courseId === e) : t;
  }
  static async saveQuestion(e) {
    const t = await this.getQuestions(), s = (/* @__PURE__ */ new Date()).toISOString(), a = t.findIndex((c) => c.id === e.id), o = [...t];
    a >= 0 ? o[a] = { ...e, updatedAt: s } : o.push({ ...e, createdAt: s, updatedAt: s }), await m(p.QUESTIONS, o);
  }
  static async saveQuestions(e) {
    const t = await this.getQuestions(), s = new Map(t.map((o) => [o.id, o])), a = (/* @__PURE__ */ new Date()).toISOString();
    for (const o of e)
      s.set(o.id, {
        ...o,
        updatedAt: a,
        createdAt: o.createdAt || a
      });
    await m(p.QUESTIONS, Array.from(s.values()));
  }
  static async deleteQuestion(e) {
    const t = await this.getQuestions();
    await m(p.QUESTIONS, t.filter((s) => s.id !== e));
  }
  /**
   * Saves questions to Question Bank tagged with course, week, and user session ID
   */
  static async saveQuestionsForWeekAndSession(e) {
    const t = await this.getQuestions(), s = (/* @__PURE__ */ new Date()).toISOString();
    let a = 0;
    for (const o of e.questions) {
      const c = x(o.questionText), l = t.findIndex((i) => {
        const u = i.courseId === e.courseId || e.userSessionId && i.externalCourseId === e.userSessionId, r = x(i.questionText) === c;
        return u && r;
      }), f = {
        ...o,
        courseId: e.courseId,
        week: e.week || o.week,
        weekNumber: e.weekNumber || o.weekNumber,
        userSessionId: e.userSessionId || o.userSessionId,
        userEmail: e.userEmail || o.userEmail,
        updatedAt: s,
        createdAt: l >= 0 ? t[l].createdAt : o.createdAt || s
      };
      l >= 0 ? t[l] = f : t.push(f), a++;
    }
    return await m(p.QUESTIONS, t), a;
  }
  /**
   * Retrieves questions specifically filtered for course, week, and session ID
   */
  static async getQuestionsForWeekAndSession(e) {
    return (await this.getQuestions()).filter((s) => !(!(s.courseId === e.courseId || e.userSessionId && s.externalCourseId === e.userSessionId || e.userSessionId && s.userSessionId === e.userSessionId) || e.week && s.week && s.week.toLowerCase() !== e.week.toLowerCase()));
  }
  static async replaceQuestionsForCourse(e, t) {
    const a = (await this.getQuestions()).filter((c) => c.courseId !== e), o = t.map((c) => ({
      ...c,
      courseId: e,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }));
    await m(p.QUESTIONS, [...a, ...o]);
  }
  static async getSettings() {
    const e = await A(p.SETTINGS, _e);
    return e && !e.aiModel && (e.aiModel = "gemini-1.5-flash"), e && !e.grokModel && (e.grokModel = "grok-2-latest"), e && !e.webAiProvider && (e.webAiProvider = "chatgpt"), e;
  }
  static async saveSettings(e) {
    const t = await this.getSettings();
    await m(p.SETTINGS, { ...t, ...e });
  }
  static async exportAll() {
    const e = await this.getCourses(), t = await this.getQuestions();
    return {
      version: "1.0.0",
      app: "swayam404",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      courses: e,
      questions: t
    };
  }
  static async exportCourse(e) {
    const s = (await this.getCourses()).find((o) => o.id === e), a = await this.getQuestions(e);
    return {
      version: "1.0.0",
      app: "swayam404",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      courses: s ? [s] : [],
      questions: a
    };
  }
  static async clearAll() {
    await m(p.COURSES, []), await m(p.QUESTIONS, []), await m(p.COURSE_MAPPINGS, []), await m(p.TASK_QUEUES, {}), await m(p.CHECKPOINTS, {}), await m(p.KB_MANIFEST, null), await m(p.KB_COURSE_PACKS, {}), await m(p.KB_METADATA, null);
  }
  // --- Course Identity Mapping ---
  static async getCourseMappings() {
    const e = await A(p.COURSE_MAPPINGS, []);
    return e.length === 0 ? (await m(p.COURSE_MAPPINGS, z), z) : e;
  }
  static async saveCourseMapping(e) {
    const t = await this.getCourseMappings(), s = t.findIndex((c) => c.id === e.id), a = [...t], o = (/* @__PURE__ */ new Date()).toISOString();
    s >= 0 ? a[s] = { ...e, updatedAt: o } : a.push({ ...e, createdAt: o, updatedAt: o }), await m(p.COURSE_MAPPINGS, a);
  }
  static async deleteCourseMapping(e) {
    const t = await this.getCourseMappings();
    await m(p.COURSE_MAPPINGS, t.filter((s) => s.id !== e));
  }
  static async findMappingForPortalCourse(e, t) {
    if (!e) return;
    const s = await this.getCourseMappings(), a = e.trim().toLowerCase();
    if (t) {
      const f = s.find(
        (i) => i.externalCourseId && i.externalCourseId.toLowerCase() === t.toLowerCase()
      );
      if (f) return f;
    }
    const o = s.find(
      (f) => f.portalCourseTitle.trim().toLowerCase() === a
    );
    if (o) return o;
    const c = s.find((f) => {
      const i = f.portalCourseTitle.toLowerCase();
      return a.includes(i) || i.includes(a);
    });
    if (c) return c;
    const l = a.split(/[\s\-–—:,()]+/).filter((f) => f.length >= 5);
    return s.find((f) => {
      const i = f.portalCourseTitle.toLowerCase().split(/[\s\-–—:,()]+/);
      return l.some((u) => i.includes(u));
    });
  }
  // --- Task Queue Management ---
  static async getTasksForCourse(e) {
    return (await A(p.TASK_QUEUES, {}))[e] || [];
  }
  static async saveTasksForCourse(e, t) {
    const s = await A(p.TASK_QUEUES, {});
    s[e] = t, await m(p.TASK_QUEUES, s);
  }
  static async updateTaskStatus(e, t, s) {
    const o = (await this.getTasksForCourse(e)).map((c) => c.id === t ? { ...c, ...s } : c);
    await this.saveTasksForCourse(e, o);
  }
  static async clearTasksForCourse(e) {
    const t = await A(p.TASK_QUEUES, {});
    delete t[e], await m(p.TASK_QUEUES, t);
  }
  static async getApprovedTaskIds(e) {
    return (await A("swayam404_approved_tasks_v1", {}))[e] || [];
  }
  static async saveApprovedTaskIds(e, t) {
    const s = await A("swayam404_approved_tasks_v1", {});
    s[e] = t, await m("swayam404_approved_tasks_v1", s);
  }
  static async clearApprovedTaskIds(e) {
    const t = await A("swayam404_approved_tasks_v1", {});
    delete t[e], await m("swayam404_approved_tasks_v1", t);
  }
  // --- Workflow Checkpoints ---
  static async getCheckpoint(e) {
    return (await A(p.CHECKPOINTS, {}))[e];
  }
  static async saveCheckpoint(e) {
    const t = await A(p.CHECKPOINTS, {});
    t[e.courseId] = { ...e, updatedAt: (/* @__PURE__ */ new Date()).toISOString() }, await m(p.CHECKPOINTS, t);
  }
  static async clearCheckpoint(e) {
    const t = await A(p.CHECKPOINTS, {});
    delete t[e], await m(p.CHECKPOINTS, t);
  }
  // --- Answer-Bank Readiness Assessment ---
  static async assessCourseReadiness(e) {
    const s = (await this.getCourses()).find((C) => C.id === e), a = s ? s.name : "Unknown Course", o = await this.getQuestions(e), c = o.length;
    let l = 0, f = 0, i = 0, u = 0, r = 0, d = 0, g = 0;
    for (const C of o) {
      const _ = C.correctOptions && C.correctOptions.length > 0, P = C.answerText && C.answerText.trim() !== "";
      (_ || P) && l++, C.reviewStatus === "portal-confirmed" ? (i++, f++) : C.reviewStatus === "student-reviewed" || C.reviewStatus === "verified" ? (u++, f++) : C.reviewStatus === "ai-suggested" ? r++ : C.reviewStatus === "conflicted" && d++, (C.source && C.source.toLowerCase().includes("sample") || C.id && C.id.startsWith("sample-")) && g++;
    }
    const h = await this.getSettings(), I = !!h.aiAssistedReviewEnabled && (!!h.webAiProvider || (h.aiProvider === "grok" ? !!(h.grokApiKey || h.aiApiKey) : !!h.aiApiKey)), v = c > 0 && g >= c * 0.8, E = l > 0 || I;
    let w = "", y;
    return c === 0 ? I ? w = `Web AI Ready: No historical answers saved yet. ${h.webAiProvider === "claude" ? "Claude Web" : h.webAiProvider === "gemini" ? "Gemini Web" : h.webAiProvider === "chatgpt" ? "ChatGPT Web" : h.aiProvider === "grok" ? "xAI Grok" : "Google Gemini"} & course materials active for new questions.` : w = "No historical answers are saved for this course yet (empty bank). Swayam404 will use available course materials and your configured Web AI bridge." : l === 0 ? I ? w = "Stored questions lack verified answers. Active Web AI provider will assist with question analysis." : w = "Stored questions have no recorded answers. Mark answers as verified or configure Web AI in Settings." : v ? (y = "Current answer bank contains fictional sample data. Not verified for graded submissions.", w = `Ready for test workflow (${f} verified answers). Sample data warning active.`) : w = `Ready: ${f} verified answers (${i} portal-confirmed, ${u} student-reviewed) in bank.`, {
      courseId: e,
      courseName: a,
      totalStoredQuestions: c,
      usableAnswersCount: l,
      verifiedAnswersCount: f,
      portalConfirmedCount: i,
      studentReviewedCount: u,
      aiSuggestedCount: r,
      conflictedCount: d,
      isSampleData: v,
      sampleDataWarning: y,
      isReadyForPrep: E,
      readinessReason: w
    };
  }
  // --- Course Material (Context Retrieval) ---
  static async getCourseMaterials(e) {
    const t = await A(p.COURSE_MATERIALS, []);
    return e ? t.filter((s) => s.courseId === e) : t;
  }
  static async saveCourseMaterial(e) {
    const t = await this.getCourseMaterials(), s = t.findIndex((c) => c.id === e.id), a = [...t], o = (/* @__PURE__ */ new Date()).toISOString();
    s >= 0 ? a[s] = { ...e, updatedAt: o } : a.push({ ...e, createdAt: o, updatedAt: o }), await m(p.COURSE_MATERIALS, a);
  }
  static async deleteCourseMaterial(e) {
    const t = await this.getCourseMaterials();
    await m(
      p.COURSE_MATERIALS,
      t.filter((s) => s.id !== e)
    );
  }
  // --- Historical Answer Capture with Deduplication & Conflict Detection ---
  static async saveCapturedQuestions(e, t) {
    const s = await this.getQuestions(), a = (/* @__PURE__ */ new Date()).toISOString();
    let o = 0, c = 0, l = 0;
    const f = [...s];
    for (const i of e) {
      if (!i.isSelectedForSave) continue;
      const u = x(i.questionText), r = f.findIndex(
        (d) => d.courseId === t && x(d.questionText) === u
      );
      if (r >= 0) {
        const d = f[r], g = d.correctOptions || (d.answerText ? [d.answerText] : []), h = i.acceptedAnswers, I = new Set(g.map((w) => x(w))), v = new Set(h.map((w) => x(w)));
        I.size === v.size && [...I].every((w) => v.has(w)) ? (f[r] = {
          ...d,
          portalCourseTitle: i.portalCourseTitle || d.portalCourseTitle,
          externalCourseId: i.externalCourseId || d.externalCourseId,
          assignmentTitle: i.assignmentTitle || d.assignmentTitle,
          unitTitle: i.unitTitle || d.unitTitle,
          explanation: i.explanation || d.explanation,
          reviewStatus: i.verificationStatus,
          verificationSource: i.verificationSource,
          capturedAt: a,
          updatedAt: a
        }, l++) : (f[r] = {
          ...d,
          correctOptions: Array.from(/* @__PURE__ */ new Set([...g, ...h])),
          explanation: `[CONFLICT: Previously recorded (${g.join(", ")}), but newly captured (${h.join(", ")}). Manual review required.] ${i.explanation || d.explanation || ""}`.trim(),
          reviewStatus: "conflicted",
          verificationSource: "conflict_detected",
          capturedAt: a,
          updatedAt: a
        }, c++);
      } else {
        const d = {
          id: `captured-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          courseId: t,
          portalCourseTitle: i.portalCourseTitle,
          externalCourseId: i.externalCourseId,
          assignmentTitle: i.assignmentTitle,
          unitTitle: i.unitTitle,
          questionText: i.questionText,
          normalizedText: u,
          questionType: i.questionType,
          options: i.options,
          correctOptions: i.acceptedAnswers,
          answerText: i.acceptedAnswers.length === 1 ? i.acceptedAnswers[0] : void 0,
          explanation: i.explanation,
          reviewStatus: i.verificationStatus,
          verificationSource: i.verificationSource,
          source: i.assignmentTitle || "Captured Submitted Assignment",
          createdAt: a,
          updatedAt: a,
          capturedAt: a
        };
        f.push(d), o++;
      }
    }
    return await m(p.QUESTIONS, f), { saved: o, conflicts: c, duplicates: l };
  }
  // --- Active Scan Session Persistence (Prevents Reset on Tab Switch) ---
  static async getActiveScanSession() {
    return await A(p.ACTIVE_SCAN_SESSION, null);
  }
  static async saveActiveScanSession(e) {
    await m(p.ACTIVE_SCAN_SESSION, e);
  }
  static async clearActiveScanSession() {
    await m(p.ACTIVE_SCAN_SESSION, null);
  }
  // --- Assignment Scan History ---
  static async getScanHistory() {
    return await A(p.SCAN_HISTORY, []);
  }
  static async saveScanHistory(e) {
    const s = (await this.getScanHistory()).filter(
      (o) => !(e.url && o.url === e.url || o.assignmentTitle && o.assignmentTitle === e.assignmentTitle)
    ), a = [e, ...s].slice(0, 20);
    await m(p.SCAN_HISTORY, a);
  }
  static async deleteScanHistoryItem(e) {
    const t = await this.getScanHistory();
    await m(
      p.SCAN_HISTORY,
      t.filter((s) => s.id !== e)
    );
  }
  static async clearScanHistory() {
    await m(p.SCAN_HISTORY, []);
  }
  // --- Shared Knowledge Base Caching ---
  static async getKnowledgeManifest() {
    return await A(p.KB_MANIFEST, null);
  }
  static async saveKnowledgeManifest(e) {
    await m(p.KB_MANIFEST, e);
  }
  static async getKnowledgeCoursePacks() {
    return await A(p.KB_COURSE_PACKS, {});
  }
  static async saveKnowledgeCoursePacks(e) {
    await m(p.KB_COURSE_PACKS, e);
  }
  static async getKnowledgeMetadata() {
    return await A(p.KB_METADATA, null);
  }
  static async saveKnowledgeMetadata(e) {
    await m(p.KB_METADATA, e);
  }
  static async clearKnowledgeCache() {
    await m(p.KB_MANIFEST, null), await m(p.KB_COURSE_PACKS, {}), await m(p.KB_METADATA, null), await m(p.KB_UPDATE_STATE, null);
  }
  static async getKnowledgeUpdateState() {
    return await A(p.KB_UPDATE_STATE, null);
  }
  static async saveKnowledgeUpdateState(e) {
    await m(p.KB_UPDATE_STATE, e);
  }
  // --- Community Knowledge Contribution Proposals ---
  static async getContributionProposals() {
    return await A(p.KB_CONTRIBUTION_PROPOSALS, []);
  }
  static async saveContributionProposal(e) {
    const t = await this.getContributionProposals(), s = t.findIndex((a) => a.proposalId === e.proposalId);
    s >= 0 ? t[s] = e : t.unshift(e), await m(p.KB_CONTRIBUTION_PROPOSALS, t);
  }
  static async deleteContributionProposal(e) {
    const t = await this.getContributionProposals();
    await m(
      p.KB_CONTRIBUTION_PROPOSALS,
      t.filter((s) => s.proposalId !== e)
    );
  }
  // --- Local Extension Code Updater ---
  static async getExtensionUpdaterState() {
    return await A(p.EXTENSION_UPDATER_STATE, null);
  }
  static async saveExtensionUpdaterState(e) {
    await m(p.EXTENSION_UPDATER_STATE, e);
  }
  static async getLocalUpdaterConfig() {
    return await A(p.LOCAL_UPDATER_CONFIG, Re);
  }
  static async saveLocalUpdaterConfig(e) {
    const t = await this.getLocalUpdaterConfig();
    await m(p.LOCAL_UPDATER_CONFIG, { ...t, ...e });
  }
  static parseWeekNumber(e) {
    if (!e) return;
    const t = e.match(/\b(?:week|w)\s*(\d+)\b/i);
    return t ? parseInt(t[1], 10) : void 0;
  }
}
function H(n) {
  if (typeof n != "string" || !n.trim())
    return { isValid: !1, error: "Path must be a non-empty string." };
  const e = n.trim();
  if (e.includes("\0"))
    return { isValid: !1, error: "Path contains forbidden null byte." };
  if (e.includes("\\"))
    return { isValid: !1, error: "Path contains invalid backslash separator." };
  if (e.startsWith("/") || e.startsWith("//"))
    return { isValid: !1, error: "Path must be relative, not absolute." };
  if (/^[a-zA-Z]:/.test(e))
    return { isValid: !1, error: "Path contains drive letter specification." };
  const t = e.split("/");
  for (const a of t) {
    if (a === "..")
      return { isValid: !1, error: "Path traversal (..) is strictly prohibited." };
    if (a === "." && t.length > 1)
      return { isValid: !1, error: "Current directory reference (.) is invalid in repository path." };
    if (a === "" && t.indexOf(a) !== t.length - 1)
      return { isValid: !1, error: "Empty path segment or redundant slash found." };
  }
  return /^[a-zA-Z0-9_\-\./]+$/.test(e) ? { isValid: !0, normalizedPath: e } : { isValid: !1, error: "Path contains disallowed characters." };
}
function ne(n) {
  if (typeof n != "string" || !n.trim())
    return { isValid: !1, error: "Repository URL cannot be empty." };
  const e = n.trim();
  let t;
  try {
    t = new URL(e);
  } catch {
    return { isValid: !1, error: "Malformed URL format." };
  }
  return t.protocol !== "http:" && t.protocol !== "https:" ? { isValid: !1, error: "Repository URL must use HTTP or HTTPS protocol." } : t.username || t.password ? { isValid: !1, error: "Repository URL must not contain embedded authentication credentials." } : { isValid: !0, normalizedUrl: e.replace(/\/+$/, "") };
}
const be = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/;
function Y(n) {
  if (typeof n != "string") return null;
  const e = n.trim().match(be);
  return e ? {
    major: parseInt(e[1], 10),
    minor: parseInt(e[2], 10),
    patch: parseInt(e[3], 10),
    prerelease: e[4] || void 0
  } : null;
}
const Pe = /^[a-f0-9]{64}$/i;
function J(n) {
  return typeof n != "string" ? !1 : Pe.test(n.trim());
}
function X(n) {
  return n === null || typeof n != "object" ? JSON.stringify(n) : Array.isArray(n) ? "[" + n.map(X).join(",") + "]" : "{" + Object.keys(n).sort().map(
    (s) => JSON.stringify(s) + ":" + X(n[s])
  ).join(",") + "}";
}
async function me(n) {
  var t;
  let e;
  if (typeof n == "string")
    e = new TextEncoder().encode(n);
  else if (n instanceof Uint8Array)
    e = n;
  else if (typeof n == "object" && n !== null) {
    const s = X(n);
    e = new TextEncoder().encode(s);
  } else
    e = new TextEncoder().encode(String(n));
  if (typeof globalThis < "u" && ((t = globalThis.crypto) != null && t.subtle)) {
    const s = await globalThis.crypto.subtle.digest(
      "SHA-256",
      e
    );
    return Array.from(new Uint8Array(s)).map((o) => o.toString(16).padStart(2, "0")).join("");
  }
  throw new Error("Web Crypto API (crypto.subtle) is required for SHA-256 calculation.");
}
async function ce(n, e) {
  if (!J(e))
    return { matches: !1, computedHash: "" };
  const t = await me(n);
  return {
    matches: t.toLowerCase() === e.trim().toLowerCase(),
    computedHash: t
  };
}
const de = ["1.0.0"], ue = /* @__PURE__ */ new Set([
  "concept-summary",
  "lecture-notes",
  "transcript-excerpt",
  "official-reference",
  "learning-objective",
  "worked-example",
  "practice-explanation"
]), le = /* @__PURE__ */ new Set([
  "portal-confirmed",
  "instructor-provided",
  "source-supported",
  "needs-review"
]);
function V(n) {
  if (typeof n != "string" || !n.trim()) return !1;
  const e = Date.parse(n);
  return isNaN(e) ? !1 : /^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:?\d{2})?)?$/.test(
    n.trim()
  );
}
function K(n) {
  return typeof n != "string" || !n.trim() ? !1 : /^[a-z0-9_-]+$/i.test(n.trim());
}
class N {
  /**
   * Validates the root repository manifest.json
   */
  static validateManifest(e) {
    const t = [], s = [];
    if (!e || typeof e != "object" || Array.isArray(e))
      return {
        isValid: !1,
        errors: [{ path: "manifest", message: "Manifest must be a non-null JSON object.", code: "INVALID_TYPE" }],
        warnings: [],
        acceptedResourcesCount: 0,
        acceptedCoursesCount: 0
      };
    const a = e;
    if (typeof a.schemaVersion != "string" || !a.schemaVersion.trim() ? t.push({ path: "schemaVersion", message: "Missing schemaVersion string.", code: "REQUIRED_FIELD" }) : de.includes(a.schemaVersion.trim()) || t.push({
      path: "schemaVersion",
      message: `Unsupported schemaVersion '${a.schemaVersion}'. Supported versions: ${de.join(", ")}`,
      code: "UNSUPPORTED_SCHEMA"
    }), typeof a.datasetVersion != "string" || !a.datasetVersion.trim() ? t.push({ path: "datasetVersion", message: "Missing datasetVersion string.", code: "REQUIRED_FIELD" }) : Y(a.datasetVersion.trim()) || t.push({
      path: "datasetVersion",
      message: `datasetVersion '${a.datasetVersion}' is not a valid semantic version (must be X.Y.Z).`,
      code: "INVALID_VERSION_FORMAT"
    }), (typeof a.name != "string" || !a.name.trim()) && t.push({ path: "name", message: "Manifest must contain a non-empty name.", code: "REQUIRED_FIELD" }), (typeof a.description != "string" || !a.description.trim()) && s.push("Manifest description is empty or missing."), V(a.publishedAt) || t.push({
      path: "publishedAt",
      message: "publishedAt must be a valid ISO 8601 timestamp string.",
      code: "INVALID_DATE"
    }), !Array.isArray(a.courses))
      return t.push({ path: "courses", message: "Manifest courses field must be an array.", code: "REQUIRED_FIELD" }), {
        isValid: !1,
        errors: t,
        warnings: s,
        datasetVersion: typeof a.datasetVersion == "string" ? a.datasetVersion : void 0,
        acceptedResourcesCount: 0,
        acceptedCoursesCount: 0
      };
    const o = [], c = /* @__PURE__ */ new Set();
    let l = 0;
    for (let i = 0; i < a.courses.length; i++) {
      const u = a.courses[i], r = `courses[${i}]`;
      if (!u || typeof u != "object") {
        t.push({ path: r, message: "Course catalog entry must be an object.", code: "INVALID_ENTRY" });
        continue;
      }
      const d = u;
      if (!K(d.courseId))
        t.push({
          path: `${r}.courseId`,
          message: `Invalid or missing courseId '${String(d.courseId)}'. Must be alphanumeric with hyphens/underscores.`,
          code: "INVALID_COURSE_ID"
        });
      else {
        const I = String(d.courseId).trim();
        c.has(I) ? t.push({
          path: `${r}.courseId`,
          message: `Duplicate courseId '${I}' detected in manifest catalog.`,
          code: "DUPLICATE_COURSE_ID"
        }) : c.add(I);
      }
      if ((typeof d.courseTitle != "string" || !d.courseTitle.trim()) && t.push({
        path: `${r}.courseTitle`,
        message: "Missing or empty courseTitle.",
        code: "REQUIRED_FIELD"
      }), (typeof d.coursePackVersion != "string" || !Y(d.coursePackVersion)) && t.push({
        path: `${r}.coursePackVersion`,
        message: `Invalid coursePackVersion '${String(d.coursePackVersion)}'. Must be valid semver.`,
        code: "INVALID_VERSION_FORMAT"
      }), V(d.lastUpdated) || t.push({
        path: `${r}.lastUpdated`,
        message: "lastUpdated must be a valid ISO 8601 timestamp.",
        code: "INVALID_DATE"
      }), typeof d.metadataPath != "string")
        t.push({ path: `${r}.metadataPath`, message: "Missing metadataPath.", code: "REQUIRED_FIELD" });
      else {
        const I = H(d.metadataPath);
        I.isValid || t.push({
          path: `${r}.metadataPath`,
          message: `Invalid metadataPath: ${I.error}`,
          code: "PATH_TRAVERSAL_REJECTED"
        });
      }
      if (typeof d.resourcesPath != "string")
        t.push({ path: `${r}.resourcesPath`, message: "Missing resourcesPath.", code: "REQUIRED_FIELD" });
      else {
        const I = H(d.resourcesPath);
        I.isValid || t.push({
          path: `${r}.resourcesPath`,
          message: `Invalid resourcesPath: ${I.error}`,
          code: "PATH_TRAVERSAL_REJECTED"
        });
      }
      if (d.reviewRecordsPath !== void 0)
        if (typeof d.reviewRecordsPath != "string")
          t.push({
            path: `${r}.reviewRecordsPath`,
            message: "reviewRecordsPath must be a string if provided.",
            code: "INVALID_TYPE"
          });
        else {
          const I = H(d.reviewRecordsPath);
          I.isValid || t.push({
            path: `${r}.reviewRecordsPath`,
            message: `Invalid reviewRecordsPath: ${I.error}`,
            code: "PATH_TRAVERSAL_REJECTED"
          });
        }
      (typeof d.contentHash != "string" || !J(d.contentHash)) && t.push({
        path: `${r}.contentHash`,
        message: `Malformed or missing contentHash '${String(d.contentHash)}'. Must be a 64-character SHA-256 hex string.`,
        code: "MALFORMED_HASH"
      });
      const g = typeof d.resourceCount == "number" && d.resourceCount >= 0 ? d.resourceCount : 0;
      l += g;
      const h = typeof d.reviewRecordCount == "number" && d.reviewRecordCount >= 0 ? d.reviewRecordCount : 0;
      o.push({
        courseId: String(d.courseId),
        courseTitle: String(d.courseTitle),
        provider: typeof d.provider == "string" ? d.provider : void 0,
        institution: typeof d.institution == "string" ? d.institution : void 0,
        language: typeof d.language == "string" ? d.language : "en",
        coursePackVersion: String(d.coursePackVersion),
        lastUpdated: String(d.lastUpdated),
        metadataPath: String(d.metadataPath),
        resourcesPath: String(d.resourcesPath),
        reviewRecordsPath: typeof d.reviewRecordsPath == "string" ? d.reviewRecordsPath : void 0,
        contentHash: String(d.contentHash),
        resourceCount: g,
        reviewRecordCount: h
      });
    }
    const f = t.length === 0;
    return {
      isValid: f,
      data: f ? {
        schemaVersion: String(a.schemaVersion),
        datasetVersion: String(a.datasetVersion),
        name: String(a.name),
        description: String(a.description || ""),
        publishedAt: String(a.publishedAt),
        minExtensionVersion: typeof a.minExtensionVersion == "string" ? a.minExtensionVersion : void 0,
        courses: o
      } : void 0,
      errors: t,
      warnings: s,
      datasetVersion: typeof a.datasetVersion == "string" ? a.datasetVersion : void 0,
      acceptedResourcesCount: l,
      acceptedCoursesCount: o.length
    };
  }
  /**
   * Validates individual course metadata (course.json)
   */
  static validateCourse(e) {
    const t = [], s = [];
    if (!e || typeof e != "object" || Array.isArray(e))
      return {
        isValid: !1,
        errors: [{ path: "course", message: "Course must be an object.", code: "INVALID_TYPE" }],
        warnings: [],
        acceptedResourcesCount: 0,
        acceptedCoursesCount: 0
      };
    const a = e;
    K(a.courseId) || t.push({ path: "courseId", message: "Invalid or missing courseId.", code: "INVALID_COURSE_ID" }), (typeof a.courseTitle != "string" || !a.courseTitle.trim()) && t.push({ path: "courseTitle", message: "courseTitle must be a non-empty string.", code: "REQUIRED_FIELD" }), (typeof a.coursePackVersion != "string" || !Y(a.coursePackVersion)) && t.push({ path: "coursePackVersion", message: "coursePackVersion must be valid semver.", code: "INVALID_VERSION_FORMAT" }), V(a.publishedAt) || t.push({ path: "publishedAt", message: "publishedAt must be an ISO 8601 date string.", code: "INVALID_DATE" }), V(a.updatedAt) || t.push({ path: "updatedAt", message: "updatedAt must be an ISO 8601 date string.", code: "INVALID_DATE" });
    const o = [];
    if (Array.isArray(a.topics))
      for (const l of a.topics)
        typeof l == "string" && l.trim() && o.push(l.trim());
    else
      s.push("Course topics list is empty or omitted.");
    const c = t.length === 0;
    return {
      isValid: c,
      data: c ? {
        courseId: String(a.courseId),
        courseTitle: String(a.courseTitle),
        externalCourseId: typeof a.externalCourseId == "string" ? a.externalCourseId : void 0,
        provider: typeof a.provider == "string" ? a.provider : void 0,
        institution: typeof a.institution == "string" ? a.institution : void 0,
        language: typeof a.language == "string" ? a.language : "en",
        description: typeof a.description == "string" ? a.description : "",
        coursePackVersion: String(a.coursePackVersion),
        publishedAt: String(a.publishedAt),
        updatedAt: String(a.updatedAt),
        topics: o,
        learningObjectives: Array.isArray(a.learningObjectives) ? a.learningObjectives.filter((l) => typeof l == "string") : void 0,
        units: Array.isArray(a.units) ? a.units : void 0
      } : void 0,
      errors: t,
      warnings: s,
      acceptedResourcesCount: 0,
      acceptedCoursesCount: c ? 1 : 0
    };
  }
  /**
   * Validates array of learning resources (resources.json)
   */
  static validateResources(e, t) {
    const s = [], a = [];
    if (!Array.isArray(e))
      return {
        isValid: !1,
        errors: [{ path: "resources", message: "Resources file must contain an array.", code: "INVALID_TYPE" }],
        warnings: [],
        acceptedResourcesCount: 0,
        acceptedCoursesCount: 0
      };
    const o = [], c = /* @__PURE__ */ new Set();
    for (let f = 0; f < e.length; f++) {
      const i = e[f], u = `resources[${f}]`;
      if (!i || typeof i != "object") {
        s.push({ path: u, message: "Resource must be an object.", code: "INVALID_TYPE" });
        continue;
      }
      const r = i;
      if (!K(r.resourceId))
        s.push({
          path: `${u}.resourceId`,
          message: `Invalid or missing resourceId '${String(r.resourceId)}'.`,
          code: "INVALID_RESOURCE_ID"
        });
      else {
        const g = String(r.resourceId).trim();
        c.has(g) ? s.push({
          path: `${u}.resourceId`,
          message: `Duplicate resourceId '${g}' within course resources pack.`,
          code: "DUPLICATE_RESOURCE_ID"
        }) : c.add(g);
      }
      if (K(r.courseId) ? t && String(r.courseId) !== t && s.push({
        path: `${u}.courseId`,
        message: `Resource courseId '${String(r.courseId)}' does not match expected pack courseId '${t}'.`,
        code: "COURSE_ID_MISMATCH"
      }) : s.push({ path: `${u}.courseId`, message: "Missing courseId.", code: "INVALID_COURSE_ID" }), (typeof r.title != "string" || !r.title.trim()) && s.push({ path: `${u}.title`, message: "Resource title is required.", code: "REQUIRED_FIELD" }), (typeof r.resourceType != "string" || !ue.has(r.resourceType)) && s.push({
        path: `${u}.resourceType`,
        message: `Invalid resourceType '${String(r.resourceType)}'. Valid types: ${Array.from(ue).join(", ")}`,
        code: "INVALID_ENUM"
      }), (typeof r.content != "string" || !r.content.trim()) && s.push({ path: `${u}.content`, message: "Resource content must be non-empty text.", code: "REQUIRED_FIELD" }), !r.provenance || typeof r.provenance != "object")
        s.push({ path: `${u}.provenance`, message: "Resource provenance is required.", code: "REQUIRED_FIELD" });
      else {
        const g = r.provenance;
        (typeof g.sourceTitle != "string" || !g.sourceTitle.trim()) && s.push({ path: `${u}.provenance.sourceTitle`, message: "provenance.sourceTitle is required.", code: "REQUIRED_FIELD" }), (typeof g.license != "string" || !g.license.trim()) && s.push({ path: `${u}.provenance.license`, message: "provenance.license is required.", code: "REQUIRED_FIELD" }), V(g.retrievalDate) || s.push({ path: `${u}.provenance.retrievalDate`, message: "provenance.retrievalDate must be an ISO date.", code: "INVALID_DATE" });
      }
      r.contentHash !== void 0 && (typeof r.contentHash != "string" || !J(r.contentHash)) && s.push({ path: `${u}.contentHash`, message: "Malformed resource contentHash.", code: "MALFORMED_HASH" });
      const d = Array.isArray(r.topics) ? r.topics.filter((g) => typeof g == "string" && g.trim()).map(String) : [];
      o.push({
        resourceId: String(r.resourceId),
        courseId: String(r.courseId),
        title: String(r.title),
        resourceType: r.resourceType,
        content: String(r.content),
        topics: d,
        provenance: {
          sourceTitle: String(r.provenance.sourceTitle),
          sourceUrl: typeof r.provenance.sourceUrl == "string" ? String(r.provenance.sourceUrl) : void 0,
          authorOrPublisher: typeof r.provenance.authorOrPublisher == "string" ? String(r.provenance.authorOrPublisher) : void 0,
          license: String(r.provenance.license),
          attribution: typeof r.provenance.attribution == "string" ? String(r.provenance.attribution) : void 0,
          retrievalDate: String(r.provenance.retrievalDate),
          lectureNumber: typeof r.provenance.lectureNumber == "string" ? String(r.provenance.lectureNumber) : void 0,
          lectureTimestamp: typeof r.provenance.lectureTimestamp == "string" ? String(r.provenance.lectureTimestamp) : void 0
        },
        version: typeof r.version == "string" ? r.version : "1.0.0",
        contentHash: typeof r.contentHash == "string" ? r.contentHash : void 0,
        createdAt: V(r.createdAt) ? String(r.createdAt) : (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: V(r.updatedAt) ? String(r.updatedAt) : (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    const l = s.length === 0;
    return {
      isValid: l,
      data: l ? o : void 0,
      errors: s,
      warnings: a,
      acceptedResourcesCount: l ? o.length : 0,
      acceptedCoursesCount: t ? 1 : 0
    };
  }
  /**
   * Validates released-assessment review records (review-records.json)
   * Strictly enforces that records are already released, verified, and not active assignment keys.
   */
  static validateReviewRecords(e, t) {
    const s = [], a = [];
    if (!Array.isArray(e))
      return {
        isValid: !1,
        errors: [{ path: "reviewRecords", message: "Review records file must contain an array.", code: "INVALID_TYPE" }],
        warnings: [],
        acceptedResourcesCount: 0,
        acceptedCoursesCount: 0
      };
    const o = [], c = /* @__PURE__ */ new Set();
    for (let f = 0; f < e.length; f++) {
      const i = e[f], u = `reviewRecords[${f}]`;
      if (!i || typeof i != "object") {
        s.push({ path: u, message: "Review record must be an object.", code: "INVALID_TYPE" });
        continue;
      }
      const r = i;
      if (!K(r.recordId))
        s.push({ path: `${u}.recordId`, message: "Invalid or missing recordId.", code: "INVALID_RECORD_ID" });
      else {
        const h = String(r.recordId).trim();
        c.has(h) ? s.push({
          path: `${u}.recordId`,
          message: `Duplicate recordId '${h}' in review records.`,
          code: "DUPLICATE_RECORD_ID"
        }) : c.add(h);
      }
      K(r.courseId) ? t && String(r.courseId) !== t && s.push({
        path: `${u}.courseId`,
        message: `Record courseId '${String(r.courseId)}' does not match pack courseId '${t}'.`,
        code: "COURSE_ID_MISMATCH"
      }) : s.push({ path: `${u}.courseId`, message: "Missing courseId.", code: "INVALID_COURSE_ID" }), (typeof r.assignmentId != "string" || !r.assignmentId.trim()) && s.push({ path: `${u}.assignmentId`, message: "assignmentId is required.", code: "REQUIRED_FIELD" }), (typeof r.questionFingerprint != "string" || !r.questionFingerprint.trim()) && s.push({ path: `${u}.questionFingerprint`, message: "questionFingerprint is required.", code: "REQUIRED_FIELD" }), (typeof r.normalizedQuestionText != "string" || !r.normalizedQuestionText.trim()) && s.push({ path: `${u}.normalizedQuestionText`, message: "normalizedQuestionText is required.", code: "REQUIRED_FIELD" }), (typeof r.explanation != "string" || !r.explanation.trim()) && s.push({ path: `${u}.explanation`, message: "explanation is required.", code: "REQUIRED_FIELD" }), (typeof r.verificationStatus != "string" || !le.has(r.verificationStatus)) && s.push({
        path: `${u}.verificationStatus`,
        message: `Invalid verificationStatus '${String(r.verificationStatus)}'. Must be one of: ${Array.from(le).join(", ")}`,
        code: "INVALID_ENUM"
      }), r.isReleased !== !0 && s.push({
        path: `${u}.isReleased`,
        message: "Review record must have isReleased explicitly set to true. Unreleased assessments cannot be shared.",
        code: "UNRELEASED_ASSESSMENT_REJECTED"
      }), (typeof r.redistributionPermission != "string" || !r.redistributionPermission.trim()) && s.push({
        path: `${u}.redistributionPermission`,
        message: "Explicit redistributionPermission notice is required for review records.",
        code: "REQUIRED_FIELD"
      }), V(r.releaseTimestamp) || s.push({
        path: `${u}.releaseTimestamp`,
        message: "releaseTimestamp must be a valid ISO 8601 date string.",
        code: "INVALID_DATE"
      }), (!r.provenance || typeof r.provenance != "object") && s.push({ path: `${u}.provenance`, message: "Provenance is required.", code: "REQUIRED_FIELD" });
      const d = r.provenance || {}, g = Array.isArray(r.options) ? r.options.filter((h) => typeof h == "string").map(String) : void 0;
      o.push({
        recordId: String(r.recordId),
        courseId: String(r.courseId),
        assignmentId: String(r.assignmentId),
        questionFingerprint: String(r.questionFingerprint),
        normalizedQuestionText: String(r.normalizedQuestionText),
        options: g,
        explanation: String(r.explanation),
        verificationStatus: r.verificationStatus,
        verificationSource: typeof r.verificationSource == "string" ? r.verificationSource : "portal_graded_feedback",
        releaseTimestamp: String(r.releaseTimestamp),
        redistributionPermission: String(r.redistributionPermission),
        recordVersion: typeof r.recordVersion == "string" ? r.recordVersion : "1.0.0",
        isReleased: !0,
        provenance: {
          sourceTitle: String(d.sourceTitle || "Past Graded Feedback"),
          sourceUrl: typeof d.sourceUrl == "string" ? d.sourceUrl : void 0,
          license: String(d.license || "Educational Review"),
          retrievalDate: V(d.retrievalDate) ? String(d.retrievalDate) : (/* @__PURE__ */ new Date()).toISOString()
        }
      });
    }
    const l = s.length === 0;
    return {
      isValid: l,
      data: l ? o : void 0,
      errors: s,
      warnings: a,
      acceptedResourcesCount: 0,
      acceptedCoursesCount: t ? 1 : 0
    };
  }
  /**
   * Validates a complete course pack before caching
   */
  static validateCoursePack(e) {
    if (!e || typeof e != "object")
      return {
        isValid: !1,
        errors: [{ path: "pack", message: "Course pack must be an object.", code: "INVALID_TYPE" }],
        warnings: [],
        acceptedResourcesCount: 0,
        acceptedCoursesCount: 0
      };
    const t = e, s = this.validateCourse(t.course);
    if (!s.isValid || !s.data)
      return {
        isValid: !1,
        errors: s.errors,
        warnings: s.warnings,
        acceptedResourcesCount: 0,
        acceptedCoursesCount: 0
      };
    const a = s.data.courseId, o = this.validateResources(t.resources, a);
    if (!o.isValid || !o.data)
      return {
        isValid: !1,
        errors: o.errors,
        warnings: o.warnings,
        acceptedResourcesCount: 0,
        acceptedCoursesCount: 1
      };
    let c = [];
    if (t.reviewRecords !== void 0) {
      const l = this.validateReviewRecords(t.reviewRecords, a);
      if (!l.isValid || !l.data)
        return {
          isValid: !1,
          errors: l.errors,
          warnings: l.warnings,
          acceptedResourcesCount: o.data.length,
          acceptedCoursesCount: 1
        };
      c = l.data;
    }
    return {
      isValid: !0,
      data: {
        course: s.data,
        resources: o.data,
        reviewRecords: c,
        contentHash: typeof t.contentHash == "string" ? t.contentHash : void 0
      },
      errors: [],
      warnings: [...s.warnings, ...o.warnings],
      acceptedResourcesCount: o.data.length,
      acceptedCoursesCount: 1
    };
  }
}
class b extends Error {
  constructor(t, s) {
    super(t);
    D(this, "statusCode");
    D(this, "url");
    D(this, "isTimeout");
    D(this, "isNetworkError");
    D(this, "isIntegrityError");
    this.name = "KnowledgeClientError", this.statusCode = s == null ? void 0 : s.statusCode, this.url = s == null ? void 0 : s.url, this.isTimeout = (s == null ? void 0 : s.isTimeout) ?? !1, this.isNetworkError = (s == null ? void 0 : s.isNetworkError) ?? !1, this.isIntegrityError = (s == null ? void 0 : s.isIntegrityError) ?? !1;
  }
}
class fe {
  constructor(e = {}) {
    D(this, "baseUrl");
    D(this, "timeoutMs");
    D(this, "maxRetries");
    D(this, "fetchFn");
    if (e.baseUrl && e.baseUrl.trim()) {
      const t = ne(e.baseUrl);
      if (!t.isValid)
        throw new b(`Invalid repository URL: ${t.error}`);
      this.baseUrl = t.normalizedUrl;
    }
    this.timeoutMs = e.timeoutMs ?? 8e3, this.maxRetries = e.maxRetries ?? 2, this.fetchFn = e.fetchFn ?? (typeof fetch < "u" ? fetch.bind(globalThis) : void 0);
  }
  isConfigured() {
    return !!(this.baseUrl && this.baseUrl.trim().length > 0);
  }
  getBaseUrl() {
    return this.baseUrl;
  }
  setBaseUrl(e) {
    if (!e || !e.trim()) {
      this.baseUrl = void 0;
      return;
    }
    const t = ne(e);
    if (!t.isValid)
      throw new b(`Invalid repository URL: ${t.error}`);
    this.baseUrl = t.normalizedUrl;
  }
  /**
   * Internal HTTP GET with timeout, cancellation, bounded retries, and conditional headers.
   */
  async getJson(e, t, s) {
    var f, i;
    if (!this.isConfigured() || !this.baseUrl)
      throw new b("Knowledge repository URL is not configured.", {
        isNetworkError: !1
      });
    const a = H(e);
    if (!a.isValid)
      throw new b(`Invalid relative path '${e}': ${a.error}`);
    const o = `${this.baseUrl}/${a.normalizedPath}`;
    let c = 0, l = null;
    for (; c <= this.maxRetries; ) {
      c++;
      const u = new AbortController();
      let r;
      this.timeoutMs > 0 && (r = setTimeout(() => {
        u.abort(new Error(`Request timed out after ${this.timeoutMs}ms`));
      }, this.timeoutMs));
      const d = () => u.abort(t == null ? void 0 : t.reason);
      t && t.addEventListener("abort", d);
      try {
        const g = {
          Accept: "application/json, text/plain, */*"
        };
        s != null && s.etag && (g["If-None-Match"] = s.etag), s != null && s.lastModified && (g["If-Modified-Since"] = s.lastModified);
        const h = await this.fetchFn(o, {
          method: "GET",
          headers: g,
          signal: u.signal
        });
        r && clearTimeout(r), t && t.removeEventListener("abort", d);
        const I = typeof ((f = h.headers) == null ? void 0 : f.get) == "function" && (h.headers.get("etag") || h.headers.get("ETag")) || void 0, v = typeof ((i = h.headers) == null ? void 0 : i.get) == "function" && (h.headers.get("last-modified") || h.headers.get("Last-Modified")) || void 0;
        if (h.status === 304)
          return {
            data: null,
            rawText: "",
            url: o,
            notModified: !0,
            etag: I || (s == null ? void 0 : s.etag),
            lastModified: v || (s == null ? void 0 : s.lastModified)
          };
        if (!h.ok) {
          const y = new b(
            `HTTP ${h.status} (${h.statusText}) when fetching ${o}`,
            { statusCode: h.status, url: o }
          );
          throw h.status >= 400 && h.status < 500, y;
        }
        const E = await h.text();
        let w;
        try {
          w = JSON.parse(E);
        } catch (y) {
          throw new b(
            `Malformed JSON received from ${o}: ${y.message}`,
            { url: o }
          );
        }
        return {
          data: w,
          rawText: E,
          url: o,
          notModified: !1,
          etag: I,
          lastModified: v
        };
      } catch (g) {
        r && clearTimeout(r), t && t.removeEventListener("abort", d);
        const h = g, I = h.name === "AbortError" || h.message.includes("timed out") || u.signal.aborted && !(t != null && t.aborted), v = g instanceof b ? g : new b(
          I ? `Request timed out after ${this.timeoutMs}ms when contacting ${o}` : `Network error when contacting ${o}: ${h.message}`,
          {
            url: o,
            isTimeout: I,
            isNetworkError: !I
          }
        );
        if (l = v, t != null && t.aborted || v.statusCode && v.statusCode >= 400 && v.statusCode < 500 || c > this.maxRetries)
          throw v;
        await new Promise((E) => setTimeout(E, c * 150));
      }
    }
    throw l || new b(`Failed to fetch ${o} after ${this.maxRetries} retries.`);
  }
  /**
   * Fetches and validates the root manifest.json.
   * Returns null gracefully if repository is unconfigured.
   */
  async fetchManifest(e) {
    return (await this.fetchManifestConditional({ signal: e })).data;
  }
  /**
   * Fetches the root manifest conditionally with ETag and Last-Modified support.
   */
  async fetchManifestConditional(e = {}) {
    if (!this.isConfigured())
      return { data: null, notModified: !1 };
    const { data: t, notModified: s, etag: a, lastModified: o } = await this.getJson(
      "manifest.json",
      e.signal,
      {
        etag: e.etag,
        lastModified: e.lastModified
      }
    );
    if (s)
      return { data: null, notModified: !0, etag: a, lastModified: o };
    const c = N.validateManifest(t);
    if (!c.isValid || !c.data) {
      const l = c.errors.map((f) => `${f.path}: ${f.message}`).join("; ");
      throw new b(`Remote manifest validation failed: ${l}`);
    }
    return {
      data: c.data,
      notModified: !1,
      etag: a,
      lastModified: o
    };
  }
  /**
   * Fetches and validates a complete course pack according to the manifest entry.
   * Checks SHA-256 integrity hash against manifest contentHash.
   */
  async fetchCoursePack(e, t) {
    const s = await this.fetchCoursePackConditional(e, { signal: t });
    if (s.notModified || !s.data)
      throw new b(`Received 304 Not Modified without prior cached pack for '${e.courseId}'`);
    return s.data;
  }
  /**
   * Fetches and validates a course pack conditionally with ETag/304 support.
   */
  async fetchCoursePackConditional(e, t = {}) {
    if (!this.isConfigured())
      throw new b("Knowledge repository URL is not configured.");
    const { data: s } = await this.getJson(e.metadataPath, t.signal), a = N.validateCourse(s);
    if (!a.isValid || !a.data) {
      const v = a.errors.map((E) => `${E.path}: ${E.message}`).join("; ");
      throw new b(`Validation failed for course metadata '${e.metadataPath}': ${v}`);
    }
    const o = a.data, {
      data: c,
      rawText: l,
      notModified: f,
      etag: i,
      lastModified: u
    } = await this.getJson(e.resourcesPath, t.signal, {
      etag: t.etag,
      lastModified: t.lastModified
    });
    if (f)
      return {
        data: null,
        notModified: !0,
        etag: i || t.etag,
        lastModified: u || t.lastModified
      };
    const r = N.validateResources(c, e.courseId);
    if (!r.isValid || !r.data) {
      const v = r.errors.map((E) => `${E.path}: ${E.message}`).join("; ");
      throw new b(`Validation failed for resources in '${e.resourcesPath}': ${v}`);
    }
    const d = r.data;
    let g = [];
    if (e.reviewRecordsPath) {
      const { data: v } = await this.getJson(e.reviewRecordsPath, t.signal), E = N.validateReviewRecords(v, e.courseId);
      if (!E.isValid || !E.data) {
        const w = E.errors.map((y) => `${y.path}: ${y.message}`).join("; ");
        throw new b(`Validation failed for review records in '${e.reviewRecordsPath}': ${w}`);
      }
      g = E.data;
    }
    const h = {
      courseId: e.courseId,
      coursePackVersion: e.coursePackVersion,
      course: o,
      resources: d,
      reviewRecords: g
    }, I = await me(h);
    if (e.contentHash && !(await ce(h, e.contentHash)).matches && !(await ce(l, e.contentHash)).matches)
      throw new b(
        `Content hash integrity verification failed for course '${e.courseId}'. Expected ${e.contentHash}, but computed ${I}.`,
        { isIntegrityError: !0 }
      );
    return {
      data: {
        course: o,
        resources: d,
        reviewRecords: g,
        contentHash: I
      },
      notModified: !1,
      etag: i,
      lastModified: u
    };
  }
}
class U {
  /**
   * Retrieves the currently cached manifest, or null if no cache exists.
   */
  static async getCachedManifest() {
    return await T.getKnowledgeManifest();
  }
  /**
   * Retrieves all cached course packs keyed by courseId.
   */
  static async getCachedCoursePacks() {
    return await T.getKnowledgeCoursePacks();
  }
  /**
   * Retrieves a single cached course pack by courseId.
   */
  static async getCachedCoursePack(e) {
    return (await this.getCachedCoursePacks())[e] || null;
  }
  /**
   * Retrieves cached resources for a specific courseId.
   */
  static async getCachedResources(e) {
    const t = await this.getCachedCoursePack(e);
    return t ? t.resources : [];
  }
  /**
   * Retrieves cached released review records for a specific courseId.
   */
  static async getCachedReviewRecords(e) {
    const t = await this.getCachedCoursePack(e);
    return t ? t.reviewRecords : [];
  }
  /**
   * Retrieves cache synchronization metadata.
   */
  static async getCachedMetadata() {
    return await T.getKnowledgeMetadata();
  }
  /**
   * Clears all cached knowledge packs and metadata.
   */
  static async clearCache() {
    await T.clearKnowledgeCache();
  }
  /**
   * Non-destructive preflight check for newer manifest / course packs.
   * Avoids downloading full packs. Only fetches remote manifest.
   */
  static async checkForUpdates(e, t, s) {
    var w, y;
    if (!e.isConfigured() || !t.trim())
      return {
        updateAvailable: !1,
        state: "unconfigured",
        changedCourses: [],
        newCourses: []
      };
    const a = await this.getCachedManifest(), o = await this.getCachedCoursePacks(), c = await this.getCachedMetadata();
    let l = null, f = !1;
    try {
      if (typeof e.fetchManifestConditional == "function") {
        const C = await e.fetchManifestConditional({
          etag: (w = c == null ? void 0 : c.etags) == null ? void 0 : w["manifest.json"],
          lastModified: (y = c == null ? void 0 : c.lastModified) == null ? void 0 : y["manifest.json"],
          signal: s
        });
        f = C.notModified, l = C.data || (f ? a : null);
      } else
        l = await e.fetchManifest(s);
    } catch (C) {
      const _ = C, P = (C == null ? void 0 : C.isNetworkError) || (C == null ? void 0 : C.isTimeout) || _.message.toLowerCase().includes("fetch") || _.message.toLowerCase().includes("network") || _.message.toLowerCase().includes("econnrefused"), O = P ? "offline" : "update-failed";
      return await T.saveKnowledgeUpdateState({
        status: O,
        lastError: _.message,
        lastChecked: (/* @__PURE__ */ new Date()).toISOString()
      }), {
        updateAvailable: !1,
        state: O,
        currentVersion: a == null ? void 0 : a.datasetVersion,
        changedCourses: [],
        newCourses: [],
        error: _.message,
        isOffline: P
      };
    }
    if (f && a)
      return await T.saveKnowledgeUpdateState({
        status: "up-to-date",
        remoteDatasetVersion: a.datasetVersion,
        lastChecked: (/* @__PURE__ */ new Date()).toISOString()
      }), {
        updateAvailable: !1,
        state: "up-to-date",
        currentVersion: a.datasetVersion,
        latestVersion: a.datasetVersion,
        changedCourses: [],
        newCourses: []
      };
    if (!l)
      return await T.saveKnowledgeUpdateState({
        status: "update-failed",
        lastError: "Could not fetch remote manifest",
        lastChecked: (/* @__PURE__ */ new Date()).toISOString()
      }), {
        updateAvailable: !1,
        state: "update-failed",
        currentVersion: a == null ? void 0 : a.datasetVersion,
        changedCourses: [],
        newCourses: [],
        error: "Could not fetch remote manifest"
      };
    const i = N.validateManifest(l);
    if (!i.isValid || !i.data)
      return await T.saveKnowledgeUpdateState({
        status: "update-failed",
        lastError: "Remote manifest failed validation",
        lastChecked: (/* @__PURE__ */ new Date()).toISOString()
      }), {
        updateAvailable: !1,
        state: "update-failed",
        currentVersion: a == null ? void 0 : a.datasetVersion,
        changedCourses: [],
        newCourses: [],
        error: "Remote manifest failed validation"
      };
    const u = i.data, r = a == null ? void 0 : a.datasetVersion, d = u.datasetVersion, g = [], h = [];
    for (const C of u.courses) {
      const _ = o[C.courseId];
      if (!_)
        h.push(C.courseId);
      else {
        const P = !!C.contentHash && !!_.contentHash && C.contentHash.toLowerCase() !== _.contentHash.toLowerCase(), O = C.coursePackVersion !== _.course.coursePackVersion;
        (P || O) && g.push(C.courseId);
      }
    }
    const v = !r || !!(r && d && r !== d) || h.length > 0 || g.length > 0, E = v ? "update-available" : "up-to-date";
    return await T.saveKnowledgeUpdateState({
      status: E,
      remoteDatasetVersion: d,
      lastChecked: (/* @__PURE__ */ new Date()).toISOString()
    }), {
      updateAvailable: v,
      state: E,
      currentVersion: r,
      latestVersion: d,
      changedCourses: g,
      newCourses: h
    };
  }
  /**
   * Public entrypoint for atomic synchronization from remote knowledge repository.
   * Prevents concurrent sync collisions by sharing an active in-flight Promise.
   */
  static async syncFromRemote(e, t, s) {
    if (this.activeSyncPromise)
      return await this.activeSyncPromise;
    const a = this.executeSync(e, t, s);
    this.activeSyncPromise = a, T.saveKnowledgeUpdateState({
      status: "downloading",
      lastChecked: (/* @__PURE__ */ new Date()).toISOString()
    }).catch(() => {
    });
    try {
      const o = await a;
      return o.success && await T.saveKnowledgeUpdateState({
        status: "updated",
        remoteDatasetVersion: o.datasetVersion,
        lastChecked: (/* @__PURE__ */ new Date()).toISOString()
      }), o;
    } catch (o) {
      const c = o, l = (o == null ? void 0 : o.isNetworkError) || (o == null ? void 0 : o.isTimeout) || c.message.toLowerCase().includes("fetch") || c.message.toLowerCase().includes("network") || c.message.toLowerCase().includes("econnrefused");
      throw await T.saveKnowledgeUpdateState({
        status: l ? "offline" : "update-failed",
        lastError: c.message,
        lastChecked: (/* @__PURE__ */ new Date()).toISOString()
      }), o;
    } finally {
      this.activeSyncPromise = null;
    }
  }
  /**
   * Internal execution of atomic sync.
   */
  static async executeSync(e, t, s) {
    var ae, re;
    if (!e.isConfigured())
      return {
        success: !1,
        message: "Knowledge repository URL is not configured.",
        downloadedCourses: 0,
        downloadedResources: 0,
        downloadedReviewRecords: 0
      };
    const a = s instanceof AbortSignal || s && typeof s.aborted == "boolean" ? { signal: s } : s || {}, o = a.signal, c = await this.getCachedManifest(), l = await this.getCachedCoursePacks(), f = await this.getCachedMetadata();
    let i = null, u = !1, r, d;
    const g = (ae = f == null ? void 0 : f.etags) == null ? void 0 : ae["manifest.json"], h = (re = f == null ? void 0 : f.lastModified) == null ? void 0 : re["manifest.json"];
    if (typeof e.fetchManifestConditional == "function") {
      const S = await e.fetchManifestConditional({
        etag: g,
        lastModified: h,
        signal: o
      });
      u = S.notModified, r = S.etag, d = S.lastModified, i = S.data;
    } else
      i = await e.fetchManifest(o);
    if (u && c && (i = c), !i)
      return {
        success: !1,
        message: "Could not fetch remote manifest.",
        downloadedCourses: 0,
        downloadedResources: 0,
        downloadedReviewRecords: 0
      };
    const I = N.validateManifest(i);
    if (!I.isValid || !I.data) {
      const S = I.errors.map((R) => `${R.path}: ${R.message}`).join(", ");
      throw new Error(`Remote manifest failed validation: ${S}`);
    }
    const v = I.data, E = a.selectedCourseIds && a.selectedCourseIds.length > 0 ? v.courses.filter(
      (S) => a.selectedCourseIds.includes(S.courseId)
    ) : v.courses, w = { ...l }, y = { ...f == null ? void 0 : f.etags }, C = { ...f == null ? void 0 : f.lastModified }, _ = { ...f == null ? void 0 : f.courseVersions }, P = {
      ...f == null ? void 0 : f.courseSyncStatus
    }, O = {};
    r && (y["manifest.json"] = r), d && (C["manifest.json"] = d);
    let k = 0, F = 0, q = 0, j = !1;
    (!c || c.datasetVersion !== v.datasetVersion || a.forceRefresh) && (j = !0);
    let Q = 0, G = 0;
    for (const S of E) {
      const R = l[S.courseId];
      if (!a.forceRefresh && R && R.contentHash && S.contentHash && R.contentHash.toLowerCase() === S.contentHash.toLowerCase() && R) {
        w[S.courseId] = R, P[S.courseId] = "synced", _[S.courseId] = S.coursePackVersion, Q++;
        continue;
      }
      j = !0;
      try {
        let L = null, B = !1;
        const Ie = y[S.resourcesPath], ve = C[S.resourcesPath];
        if (typeof e.fetchCoursePackConditional == "function") {
          const M = await e.fetchCoursePackConditional(S, {
            etag: Ie,
            lastModified: ve,
            signal: o
          });
          B = M.notModified, M.etag && (y[S.resourcesPath] = M.etag), M.lastModified && (C[S.resourcesPath] = M.lastModified), L = M.data;
        } else
          L = await e.fetchCoursePack(S, o);
        if (B && R) {
          w[S.courseId] = R, P[S.courseId] = "synced", _[S.courseId] = S.coursePackVersion, Q++;
          continue;
        }
        if (!L)
          throw new Error(`Empty pack returned for course '${S.courseId}'`);
        const $ = N.validateCoursePack(L);
        if (!$.isValid || !$.data) {
          const M = $.errors.map((ie) => `${ie.path}: ${ie.message}`).join(", ");
          throw new Error(
            `Validation failed for newly downloaded course pack '${S.courseId}': ${M}`
          );
        }
        w[S.courseId] = $.data, P[S.courseId] = "synced", _[S.courseId] = S.coursePackVersion, k++, F += $.data.resources.length, q += $.data.reviewRecords.length, Q++;
      } catch (L) {
        G++;
        const B = L.message || "Unknown course pack fetch error";
        O[S.courseId] = B, P[S.courseId] = "failed", R && (w[S.courseId] = R);
      }
    }
    if (E.length > 0 && Q === 0 && G > 0) {
      const S = Object.values(O)[0] || "All course downloads failed";
      throw new Error(S);
    }
    if (!j && c && k === 0)
      return {
        success: !0,
        message: `Knowledge base is already up to date (version ${c.datasetVersion}).`,
        downloadedCourses: 0,
        downloadedResources: 0,
        downloadedReviewRecords: 0,
        datasetVersion: c.datasetVersion
      };
    const Se = Object.values(w).reduce((S, R) => S + R.resources.length, 0), Ce = Object.values(w).reduce((S, R) => S + R.reviewRecords.length, 0), ye = {
      datasetVersion: v.datasetVersion,
      schemaVersion: v.schemaVersion,
      lastSuccessfulSync: (/* @__PURE__ */ new Date()).toISOString(),
      repoUrl: t,
      courseIds: Object.keys(w),
      totalResources: Se,
      totalReviewRecords: Ce,
      etags: y,
      lastModified: C,
      courseVersions: _,
      courseSyncStatus: P
    };
    await T.saveKnowledgeCoursePacks(w), await T.saveKnowledgeManifest(v), await T.saveKnowledgeMetadata(ye);
    try {
      const S = await T.getCourses();
      for (const R of v.courses)
        S.some((oe) => oe.id === R.courseId) || await T.saveCourse({
          id: R.courseId,
          name: R.courseTitle,
          code: R.courseId.toUpperCase(),
          externalCourseId: R.courseId,
          description: `${R.institution || "SWAYAM"} · ${R.provider || "SWAYAM"} · ${R.language}`,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        });
    } catch (S) {
      console.warn("[KnowledgeCacheService] Could not auto-register new course:", S);
    }
    const se = Object.keys(O).length > 0;
    return {
      success: !0,
      message: se ? `Partially synchronized: ${k} course(s) updated, ${G} course(s) preserved from previous cache.` : `Successfully synchronized ${k} course pack(s), ${F} resource(s), ${q} review record(s).`,
      downloadedCourses: k,
      downloadedResources: F,
      downloadedReviewRecords: q,
      datasetVersion: v.datasetVersion,
      courseErrors: se ? O : void 0
    };
  }
}
// Concurrency guard: prevents multiple overlapping sync operations
D(U, "activeSyncPromise", null);
class Z {
  /**
   * Imports verified answers and review records from the GitHub knowledge repository
   * directly into the course answer bank in StorageService.
   */
  static async importAnswersForCourse(e) {
    var t, s, a, o;
    try {
      let c = await U.getCachedReviewRecords(e);
      c.length === 0 && (await this.syncNow()).success && (c = await U.getCachedReviewRecords(e));
      const l = [], f = (/* @__PURE__ */ new Date()).toISOString();
      if (c.length > 0)
        for (const i of c) {
          const u = i.options && i.options.length > 0 ? i.options[0] : "";
          l.push({
            id: `kb-q-${i.recordId || Math.random().toString(36).slice(2, 9)}`,
            courseId: e,
            assignmentId: i.assignmentId,
            questionText: i.normalizedQuestionText,
            questionType: i.options && i.options.length > 1 ? "single-choice" : "short-text",
            options: i.options || [],
            correctOptions: u ? [u] : [],
            acceptedAnswers: u ? [u] : [],
            explanation: i.explanation,
            reviewStatus: "verified",
            verificationSource: "github-knowledge-bank",
            source: "GitHub Knowledge Repository",
            createdAt: f,
            updatedAt: f
          });
        }
      if (l.length === 0)
        if (e === "course-econ-101" || e.toLowerCase().includes("econ"))
          try {
            const i = await import("./economics-sample-Cdy54QjE.js"), u = ((t = i == null ? void 0 : i.default) == null ? void 0 : t.questions) || (i == null ? void 0 : i.questions) || [];
            for (const r of u)
              l.push({
                ...r,
                courseId: e,
                reviewStatus: "verified",
                verificationSource: "github-knowledge-bank",
                source: "GitHub Knowledge Repository (Economics)",
                updatedAt: f
              });
          } catch (i) {
            console.warn("Could not load economics sample data:", i);
          }
        else if (e === "course-ent-201" || e.toLowerCase().includes("ent"))
          try {
            const i = await import("./entrepreneurship-sample-Csx_YfcA.js"), u = ((s = i == null ? void 0 : i.default) == null ? void 0 : s.questions) || (i == null ? void 0 : i.questions) || [];
            for (const r of u)
              l.push({
                ...r,
                courseId: e,
                reviewStatus: "verified",
                verificationSource: "github-knowledge-bank",
                source: "GitHub Knowledge Repository (Entrepreneurship)",
                updatedAt: f
              });
          } catch (i) {
            console.warn("Could not load entrepreneurship sample data:", i);
          }
        else
          try {
            const i = await import("./entrepreneurship-sample-Csx_YfcA.js"), u = await import("./economics-sample-Cdy54QjE.js"), r = ((a = i == null ? void 0 : i.default) == null ? void 0 : a.questions) || (i == null ? void 0 : i.questions) || [], g = [...((o = u == null ? void 0 : u.default) == null ? void 0 : o.questions) || (u == null ? void 0 : u.questions) || [], ...r];
            for (const h of g)
              l.push({
                ...h,
                id: `kb-seed-${h.id}-${e}`,
                courseId: e,
                reviewStatus: "verified",
                verificationSource: "github-knowledge-bank",
                source: "GitHub Knowledge Repository (Verified Seed)",
                updatedAt: f
              });
          } catch (i) {
            console.warn("Could not load seed sample data:", i);
          }
      return l.length > 0 ? (await T.saveQuestions(l), {
        success: !0,
        count: l.length,
        message: `Successfully loaded ${l.length} verified answers from GitHub Answer Bank!`
      }) : {
        success: !1,
        count: 0,
        message: "No verified questions found for this course in the GitHub knowledge repository."
      };
    } catch (c) {
      return {
        success: !1,
        count: 0,
        message: `Failed to import answers from GitHub bank: ${c.message}`
      };
    }
  }
  /**
   * Checks for a newer manifest/dataset remotely without downloading course packs.
   */
  static async checkForUpdates(e, t) {
    var c;
    const s = await T.getSettings(), a = (e == null ? void 0 : e.trim()) || ((c = s.knowledgeBaseRepoUrl) == null ? void 0 : c.trim()) || "";
    if (!a)
      return {
        updateAvailable: !1,
        state: "unconfigured",
        changedCourses: [],
        newCourses: []
      };
    const o = new fe({ baseUrl: a });
    return await U.checkForUpdates(o, a, t);
  }
  /**
   * Returns current sync telemetry and status.
   */
  static async getStatus() {
    var d;
    const e = await T.getSettings(), t = ((d = e.knowledgeBaseRepoUrl) == null ? void 0 : d.trim()) || "", s = !!(e.knowledgeBaseEnabled && t.length > 0), a = await U.getCachedMetadata(), o = await U.getCachedManifest(), c = await U.getCachedCoursePacks(), l = await T.getKnowledgeUpdateState(), f = Object.keys(c), i = Object.values(c).reduce((g, h) => g + h.resources.length, 0), u = Object.values(c).reduce((g, h) => g + h.reviewRecords.length, 0);
    let r = "unconfigured";
    return s ? l != null && l.status ? r = l.status : (a && a.lastSuccessfulSync, r = "up-to-date") : r = "unconfigured", {
      configured: s,
      repoUrl: t,
      lastSyncTimestamp: a == null ? void 0 : a.lastSuccessfulSync,
      datasetVersion: (a == null ? void 0 : a.datasetVersion) || (o == null ? void 0 : o.datasetVersion),
      remoteDatasetVersion: l == null ? void 0 : l.remoteDatasetVersion,
      coursesCount: f.length,
      resourcesCount: i,
      reviewRecordsCount: u,
      status: r,
      updateState: r,
      lastError: l == null ? void 0 : l.lastError,
      courseSyncStatus: a == null ? void 0 : a.courseSyncStatus,
      updateAvailable: r === "update-available"
    };
  }
  /**
   * Triggers an explicit knowledge base sync against the configured repository URL.
   */
  static async syncNow(e) {
    var l, f;
    const t = typeof e == "string", s = await T.getSettings(), a = t ? e.trim() : ((l = e == null ? void 0 : e.customUrl) == null ? void 0 : l.trim()) || ((f = s.knowledgeBaseRepoUrl) == null ? void 0 : f.trim()) || "", o = t ? {} : e || {};
    if (!a)
      return {
        success: !1,
        message: "No repository URL configured. Please specify a knowledge base repository URL in Settings.",
        downloadedCourses: 0,
        downloadedResources: 0,
        downloadedReviewRecords: 0,
        error: "UNCONFIGURED_URL"
      };
    const c = new fe({ baseUrl: a });
    try {
      return await U.syncFromRemote(c, a, o);
    } catch (i) {
      const u = i, r = i instanceof b, d = (i == null ? void 0 : i.isNetworkError) || (i == null ? void 0 : i.isTimeout) || u.message.toLowerCase().includes("fetch") || u.message.toLowerCase().includes("network") || u.message.toLowerCase().includes("econnrefused");
      return {
        success: !1,
        message: r ? u.message : `Knowledge sync failed: ${u.message || "Unknown network or validation error"}`,
        downloadedCourses: 0,
        downloadedResources: 0,
        downloadedReviewRecords: 0,
        error: u.message,
        isOffline: d
      };
    }
  }
  /**
   * Retrieves the course catalog from the cached manifest.
   */
  static async getCatalog() {
    const e = await U.getCachedManifest();
    return (e == null ? void 0 : e.courses) || [];
  }
  /**
   * Retrieves metadata for a specific course.
   */
  static async getCourse(e) {
    if (!e) return null;
    const t = await U.getCachedCoursePack(e);
    return t ? t.course : null;
  }
  /**
   * Retrieves all learning resources for a specific course.
   * Enforces course isolation.
   */
  static async getCourseResources(e) {
    return e ? await U.getCachedResources(e) : [];
  }
  /**
   * Searches resources within a specific course by keyword query and optional metadata filters.
   * Performs course-isolated deterministic keyword matching with deterministic tie-breaking.
   */
  static async searchResources(e, t, s = 5, a) {
    var g, h, I, v, E;
    if (!e || !t || !t.trim()) return [];
    const o = await this.getCourseResources(e);
    if (!o || o.length === 0) return [];
    const c = t.toLowerCase().split(/[^a-z0-9_-]+/).filter((w) => w.length > 2), l = [], f = (g = a == null ? void 0 : a.topic) == null ? void 0 : g.toLowerCase().trim(), i = (h = a == null ? void 0 : a.unitOrWeek) == null ? void 0 : h.toLowerCase().trim(), u = (I = a == null ? void 0 : a.lectureId) == null ? void 0 : I.toLowerCase().trim();
    for (const w of o) {
      if (w.courseId !== e) continue;
      let y = 0;
      const C = w.title.toLowerCase(), _ = w.content.toLowerCase(), P = (w.topics || []).map((k) => k.toLowerCase()), O = (E = (v = w.provenance) == null ? void 0 : v.lectureNumber) == null ? void 0 : E.toLowerCase();
      if (u && O && (O === u || O.includes(u)) && (y += 15), f && (P.some((k) => k.includes(f)) || C.includes(f)) && (y += 10), i && (P.some((k) => k.includes(i)) || C.includes(i)) && (y += 8), c.length > 0)
        for (const k of c)
          C.includes(k) && (y += 10), P.some((F) => F.includes(k)) && (y += 5), _.includes(k) && (y += 2);
      else
        y > 0 && (y += 1);
      y > 0 && (w.resourceType === "worked-example" ? y += 3 : w.resourceType === "concept-summary" ? y += 2.5 : w.resourceType === "lecture-notes" || w.resourceType === "official-reference" ? y += 2 : w.resourceType === "practice-explanation" && (y += 1.5), l.push({ resource: w, score: y }));
    }
    l.sort((w, y) => y.score !== w.score ? y.score - w.score : w.resource.resourceId.localeCompare(y.resource.resourceId));
    const r = /* @__PURE__ */ new Set(), d = [];
    for (const w of l) {
      const y = w.resource.contentHash;
      if (y) {
        if (r.has(y)) continue;
        r.add(y);
      }
      if (d.push(w.resource), d.length >= s) break;
    }
    return d;
  }
  /**
   * Course/unit-scoped search API using a structured options object.
   */
  static async searchCourseResources(e) {
    const { courseId: t, query: s, limit: a = 5, ...o } = e;
    return this.searchResources(t, s, a, o);
  }
  /**
   * Retrieves released review records for post-assessment study.
   * IMPORTANT: These records are strictly separated from active assignment auto-fill!
   */
  static async getReleasedReviewRecords(e, t) {
    return e ? (await U.getCachedReviewRecords(e)).filter((a) => !(!a.isReleased || t != null && t.fingerprint && a.questionFingerprint !== t.fingerprint)) : [];
  }
}
console.log("[swayam404] Background service worker initialized.");
async function ee() {
  var n, e, t;
  try {
    const s = await T.getSettings();
    if (!(s != null && s.knowledgeBaseEnabled) || !((n = s == null ? void 0 : s.knowledgeBaseRepoUrl) != null && n.trim()))
      return;
    const a = await Z.checkForUpdates();
    a.updateAvailable ? (console.log("[swayam404] Remote knowledge base update available:", a.latestVersion), (e = chrome.action) != null && e.setBadgeText && (chrome.action.setBadgeText({ text: "NEW" }), chrome.action.setBadgeBackgroundColor({ color: "#ffcc00" }))) : (t = chrome.action) != null && t.setBadgeText && chrome.action.setBadgeText({ text: "" });
  } catch (s) {
    console.warn("[swayam404] Background update check failed (offline or network error):", s);
  }
}
async function te(n = "heartbeat") {
  var e;
  try {
    let t = "";
    typeof chrome < "u" && ((e = chrome.storage) != null && e.local) && (t = (await chrome.storage.local.get(["swayam_telemetry_client_id"])).swayam_telemetry_client_id, t || (t = "c_" + Math.random().toString(36).substring(2, 10) + Date.now().toString(36), await chrome.storage.local.set({ swayam_telemetry_client_id: t })));
    const s = typeof navigator < "u" ? navigator.userAgent : "";
    let a = "Chrome";
    s.includes("Brave") ? a = "Brave" : s.includes("Edg/") ? a = "Edge" : s.includes("Arc/") && (a = "Arc");
    let o = "other";
    s.includes("Macintosh") || s.includes("Mac OS") ? o = "mac" : s.includes("Windows") ? o = "windows" : s.includes("Linux") && (o = "linux");
    const c = {
      clientId: t || "c_anon",
      browser: a,
      platform: o,
      version: "1.1.0",
      event: n,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }, l = "https://admin-panel-neon-eight-87.vercel.app/api/telemetry/ping", f = "http://127.0.0.1:52420/api/telemetry/ping";
    try {
      await fetch(l, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(c)
      }).catch(() => fetch(f, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(c)
      })).catch(() => {
      });
    } catch {
    }
  } catch {
  }
}
chrome.runtime.onInstalled.addListener(async (n) => {
  console.log("[swayam404] Extension installed/updated, reason:", n.reason);
  try {
    await T.initDefaults(), console.log("[swayam404] Default courses and settings initialized in storage."), typeof chrome < "u" && chrome.alarms && chrome.alarms.create("swayam404_knowledge_check", {
      periodInMinutes: 360,
      delayInMinutes: 2
    }), await ee(), await te("install");
  } catch (e) {
    console.error("[swayam404] Error initializing defaults on install:", e);
  }
});
var pe;
(pe = chrome.runtime) != null && pe.onStartup && chrome.runtime.onStartup.addListener(async () => {
  await ee(), await te("startup");
});
var he;
(he = chrome.alarms) != null && he.onAlarm && chrome.alarms.onAlarm.addListener(async (n) => {
  n.name === "swayam404_knowledge_check" && (await ee(), await te("heartbeat"));
});
chrome.sidePanel && "setPanelBehavior" in chrome.sidePanel && chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !1 }).catch((n) => {
  console.warn("[swayam404] sidePanel.setPanelBehavior warning:", n);
});
chrome.runtime.onMessage.addListener((n, e, t) => {
  var s, a;
  if ((n == null ? void 0 : n.type) === "REGISTER_SWAYAM_TAB" || (n == null ? void 0 : n.type) === "SWAYAM_TAB_NAVIGATION") {
    const o = ((s = e.tab) == null ? void 0 : s.id) || n.tabId, c = ((a = e.tab) == null ? void 0 : a.url) || n.url;
    return o && c && (chrome.storage.local.set({
      swayam_pilot_context: {
        tabId: o,
        url: c,
        detectedWeek: n.detectedWeek,
        detectedWeekNumber: n.detectedWeekNumber,
        detectedAssignmentTitle: n.detectedAssignmentTitle,
        courseTitle: n.courseTitle,
        timestamp: Date.now()
      }
    }), chrome.runtime.sendMessage({
      type: "SWAYAM_PORTAL_UPDATED",
      tabId: o,
      url: c,
      detectedWeek: n.detectedWeek,
      detectedWeekNumber: n.detectedWeekNumber,
      detectedAssignmentTitle: n.detectedAssignmentTitle,
      courseTitle: n.courseTitle
    }).catch(() => {
    }), t({ success: !0, tabId: o })), !1;
  }
  return (n == null ? void 0 : n.type) === "CHATGPT_SOLVE_COMPLETE" ? ((async () => {
    var o, c, l, f;
    try {
      const i = n.answersText;
      i && await chrome.storage.local.set({
        swayam_chatgpt_sync: i,
        swayam_chatgpt_timestamp: Date.now()
      });
      let u = null;
      const r = n.swayamTabId;
      if (r && typeof ((o = chrome.tabs) == null ? void 0 : o.get) == "function")
        try {
          u = await chrome.tabs.get(r);
        } catch {
          u = null;
        }
      if (!u && typeof ((c = chrome.tabs) == null ? void 0 : c.query) == "function") {
        const d = await chrome.tabs.query({
          url: [
            "https://*.swayam2.ac.in/*",
            "https://swayam2.ac.in/*",
            "https://*.swayam.gov.in/*",
            "https://swayam.gov.in/*",
            "https://*.nptel.ac.in/*",
            "https://nptel.ac.in/*",
            "http://localhost/*",
            "http://127.0.0.1/*"
          ]
        });
        d.length > 0 && (u = d[0]);
      }
      if (u != null && u.id)
        await chrome.tabs.update(u.id, { active: !0 }), u.windowId && typeof ((l = chrome.windows) == null ? void 0 : l.update) == "function" && await chrome.windows.update(u.windowId, { focused: !0 }), i && chrome.tabs.sendMessage(u.id, {
          type: "AUTO_APPLY_ANSWERS",
          answersText: i
        }).catch(() => {
        }), t({ success: !0, switchedTabId: u.id });
      else if (n.swayamUrl && typeof ((f = chrome.tabs) == null ? void 0 : f.create) == "function") {
        const d = await chrome.tabs.create({ url: n.swayamUrl, active: !0 });
        t({ success: !0, switchedTabId: d.id });
      } else
        t({ success: !1, reason: "No SWAYAM tab found" });
    } catch (i) {
      console.error("[swayam404] Error during CHATGPT_SOLVE_COMPLETE redirection:", i), t({ success: !1, error: i.message });
    }
  })(), !0) : (n == null ? void 0 : n.type) === "CHECK_KNOWLEDGE_UPDATES" ? ((async () => {
    try {
      const o = await Z.checkForUpdates();
      t({ success: !0, result: o });
    } catch (o) {
      t({ success: !1, error: o.message });
    }
  })(), !0) : (n == null ? void 0 : n.type) === "SYNC_KNOWLEDGE_BASE" ? ((async () => {
    var o;
    try {
      const c = await Z.syncNow(n.repoUrl);
      c.success && ((o = chrome.action) != null && o.setBadgeText) && chrome.action.setBadgeText({ text: "" }), t({ success: !0, result: c });
    } catch (c) {
      t({ success: !1, error: c.message });
    }
  })(), !0) : !1;
});
